const allCharacterButton = document.querySelector("#all-character-button");
const allLocationButton = document.querySelector("#all-location-button");
const allEpisodeButton = document.querySelector("#all-episode-button");

const allCharacterUrl = "https://rickandmortyapi.com/api/character";
const allLocationUrl = "https://rickandmortyapi.com/api/location";
const allEpisodeUrl = "https://rickandmortyapi.com/api/episode";

const characterID = document.querySelector("#character-id-input");
const locationID = document.querySelector("#location-id-input");
const episodeID = document.querySelector("#episode-id-input");

const specificCharacter = document.querySelector("#specific-character-button");
const specificLocation = document.querySelector("#specific-location-button");
const specificEpisode = document.querySelector("#specific-episode-button");

const characterResutls = document.querySelector("#display-results-character");
const locationResutls = document.querySelector("#display-results-location");
const episodeResutls = document.querySelector("#display-results-episode");



const errorMessage = "Sometimes Science Is More Art Than Science. Whatever ID you tried, try again... Hopefully this time you fail better.";

function clearPreviousResults(selectedDiv) {
  if (selectedDiv.hasChildNodes()) {
    while (selectedDiv.firstElementChild) {
      selectedDiv.removeChild(selectedDiv.firstChild);
    }
    selectedDiv.textContent = "";
    selectedDiv.classList.remove("error");
  } else {
    selectedDiv.textContent = "";
    selectedDiv.classList.remove("error");
  }
}

function errorMessageFunction(selectedDiv) {
  selectedDiv.textContent = `${errorMessage}`;
  selectedDiv.classList.add("error");
}

function getResults(urlLink, selectedID, spaceToDisplay, secondAttribute, thirdAttribute) {
  clearPreviousResults(spaceToDisplay);
  if (selectedID) {
    let idReference;
    if (selectedID.value) {
      idReference = selectedID.value;
    } else {
      idReference = selectedID;
    }
    let combinedLink = `${urlLink}/${idReference}`;
    fetch(`${combinedLink}`, {
      method: "GET",
    })
      .then(function (response) {
        return response.json();
      })
      .then(function (jsonResp) {
        if (jsonResp.name) {
          spaceToDisplay.textContent = `${jsonResp.name} | ${jsonResp[secondAttribute]} | ${jsonResp[thirdAttribute]}`;
          console.log(jsonResp);
        } else {
          errorMessageFunction(spaceToDisplay);
        }
      });
  } else {
    let pageNumber = "?page=";
    fetch(`${urlLink}`, {
      method: "GET",
    })
      .then(function (response) {
        return response.json();
      })
      .then(function (jsonResp) {
        if (jsonResp.info) {
          console.log(jsonResp.info.pages);
          for (i = 1; i <= jsonResp.info.pages; i++) {
            fetch(`${urlLink}/${pageNumber}${i}`, {
              method: "GET",
            })
              .then(function (response) {
                return response.json();
              })
              .then(function (jsonResp) {
                console.log(jsonResp.results);
                for (let i = 0; i < jsonResp.results.length; i++) {
                  const paragraph = spaceToDisplay.appendChild(
                    document.createElement("p")
                  );

                  paragraph.textContent = `${jsonResp.results[i].name} | ${jsonResp.results[i][secondAttribute]} | ${jsonResp.results[i][thirdAttribute]}`;

                }
              });
          }
        } else {
          fetch(`${urlLink}`, {
            method: "GET",
          })
            .then(function (response) {
              return response.json();
            })
            .then(function (jsonResp) {
              if (jsonResp.name) {
                spaceToDisplay.textContent = `${jsonResp.name} | ${jsonResp[secondAttribute]} | ${jsonResp[thirdAttribute]}`;
                console.log(jsonResp);
              } else {
                errorMessageFunction(spaceToDisplay);
              }
            });
        }
      });
  }
}

const characterStatus = "status";
const characterSpecies = "species";

const locationType = "type";
const locationDimension = "dimension";

const episodeAirDate = "air_date";
const episodeEpisode = "episode";

allCharacterButton.addEventListener("click", function () {
  getResults(allCharacterUrl, undefined, characterResutls, characterStatus, characterSpecies);
});
allLocationButton.addEventListener("click", function () {
  getResults(allLocationUrl, undefined, locationResutls, locationType, locationDimension);
});
allEpisodeButton.addEventListener("click", function () {
  getResults(allEpisodeUrl, undefined, episodeResutls, episodeAirDate, episodeEpisode);
});

specificCharacter.addEventListener("click", function () {
  getResults(allCharacterUrl, characterID, characterResutls, characterStatus, characterSpecies);
});
specificLocation.addEventListener("click", function () {
  getResults(allLocationUrl, locationID, locationResutls, locationType, locationDimension);
});
specificEpisode.addEventListener("click", function () {
  getResults(allEpisodeUrl, episodeID, episodeResutls, episodeAirDate, episodeEpisode);
});

//fun bonus

const rickButton = document.querySelector("#rick-picture");
const rickId = 1;

const mortyButton = document.querySelector("#morty-picture");
const mortyId = 2;


rickButton.addEventListener("click", function () {
  getResults(allCharacterUrl, rickId, characterResutls, characterStatus, characterSpecies);
});

mortyButton.addEventListener("click", function () {
  getResults(allCharacterUrl, mortyId, characterResutls, characterStatus, characterSpecies);
});




//Original homework: simple function that would fecth either all or one result based on url

// function getResults(urlLink) {
//   let pageNumber = "?page=";

//   fetch(`${urlLink}`, {
//     method: "GET",
//   })
//     .then(function (response) {
//       return response.json();
//     })

//     .then(function (jsonResp) {
//       if (jsonResp.info) {
//         console.log(jsonResp.info.pages);

//         for (i = 1; i <= jsonResp.info.pages; i++) {
//           fetch(`${urlLink}/${pageNumber}${i}`, {
//             method: "GET",
//           })
//             .then(function (response) {
//               return response.json();
//             })

//             .then(function (jsonResp) {
//               console.log(jsonResp.results);
//             });
//         }
//       } else {
//         fetch(`${urlLink}`, {
//           method: "GET",
//         })
//           .then(function (response) {
//             return response.json();
//           })

//           .then(function (jsonResp) {
//             console.log(jsonResp);
//           });
//       }
//     });
// }

// link = "https://rickandmortyapi.com/api/episode/7";

// console.log(getResults(link));
