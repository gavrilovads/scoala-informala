const feedbackForm = document.querySelector("#feedback-form");
const toastMessage = document.querySelector(".toast-message");
const happyToastIcon = document.querySelector(".fa-circle-check");
const sadToastIcon = document.querySelector(".fa-circle-xmark");
const happyToastText = document.querySelector(".success-message-text");
const sadToastText = document.querySelector(".error-message-text");
const closeToastButton = document.querySelector("#close-toast");
const genderFemaleRadio = document.querySelector("#gf");
const genderMaleRadio = document.querySelector("#gm");
const textArea = document.querySelector("#feedback-text-area");
const successText = "Thank you for contacting us, ";
const errorText = "Looks like you forgot something...";
const firstNameSpan = document.querySelector("#first-name-span");
const lastNameSpan = document.querySelector("#last-name-span");

const firstNameInput = document.querySelector("#first-name");
const lastNameInput = document.querySelector("#last-name");

const submitButton = document.querySelector(".submit-button");

function invalidField(testValue) {
  if (testValue) {
    return false;
  } else {
    return true;
  }
}

function closeToast() {
  toastMessage.style.visibility = "hidden";
}

function autoCloseToast(target) {
  setTimeout(function () {
    target.style.visibility = "hidden";
  }, 3000);
}

function checkError(isError) {
  let firstNameValue = firstNameInput.value;
  if (isError) {
    toastMessage.style.visibility = "visible";
    toastMessage.style.borderColor = "var(--errorDeep)";
    toastMessage.style.backgroundColor = "var(--errorPale)";
    sadToastText.textContent = `${errorText}`;
    sadToastText.style.display = "flex";
    sadToastIcon.style.display = "flex";
    sadToastText.style.color = "var(--errorDeep)";
    sadToastIcon.style.color = "var(--errorDeep)";
    happyToastIcon.style.display = "none";
    happyToastText.style.display = "none";
    autoCloseToast(toastMessage);
  } else {
    toastMessage.style.visibility = "visible";
    toastMessage.style.borderColor = "var(--successDeep)";
    toastMessage.style.backgroundColor = "var(--successPale)";
    happyToastText.textContent = `${successText}${firstNameValue}!`;
    happyToastText.style.display = "flex";
    happyToastIcon.style.display = "flex";
    happyToastText.style.color = "var(--successDeep)";
    happyToastIcon.style.color = "var(--successDeep)";
    sadToastIcon.style.display = "none";
    sadToastText.style.display = "none";
    firstNameSpan.style.visibility = "hidden";
    lastNameSpan.style.visibility = "hidden";
    firstNameInput.style.boxShadow = "none";
    lastNameInput.style.boxShadow = "none";
    autoCloseToast(toastMessage);
  }
}

function logFeedback() {
  let firstNameValue = firstNameInput.value;
  let lastNameValue = lastNameInput.value;
  let genderFemaleValue = genderFemaleRadio.checked;
  let genderMaleValue = genderMaleRadio.checked;
  let textAreaValue = textArea.value;

  console.log(`First Name: ${firstNameValue}`);
  console.log(`Last Name: ${lastNameValue}`);
  console.log(`Gender female: ${genderFemaleValue}`);
  console.log(`Gender male: ${genderMaleValue}`);
  console.log(`Feedback: ${textAreaValue}`);
}

function submitForm() {
  let firstNameValue = firstNameInput.value;
  let lastNameValue = lastNameInput.value;

  logFeedback();
  if (invalidField(firstNameValue) && invalidField(lastNameValue)) {
    firstNameInput.style.boxShadow = "0 0 4px var(--error-accentColor)";
    lastNameInput.style.boxShadow = "0 0 4px var(--error-accentColor)";
    firstNameSpan.style.visibility = "visible";
    firstNameSpan.style.color = "var(--errorSpan)";
    lastNameSpan.style.visibility = "visible";
    lastNameSpan.style.color = "var(--errorSpan)";
    let testValue = true;
    checkError(testValue);
  } else if (invalidField(firstNameValue)) {
    firstNameInput.style.boxShadow = "0 0 4px var(--error-accentColor)";
    firstNameSpan.style.visibility = "visible";
    firstNameSpan.style.color = "var(--errorSpan)";
    let testValue = true;
    checkError(testValue);
  } else if (invalidField(lastNameValue)) {
    lastNameInput.style.boxShadow = "0 0 4px var(--error-accentColor)";
    lastNameSpan.style.visibility = "visible";
    lastNameSpan.style.color = "var(--errorSpan)";
    let testValue = true;
    checkError(testValue);
  } else {
    let testValue = false;
    checkError(testValue);
    feedbackForm.reset();
  }
}

firstNameInput.addEventListener("blur", blurFirstName);
function blurFirstName() {
  let firstNameValue = firstNameInput.value;

  if (firstNameValue) {
    firstNameSpan.style.visibility = "hidden";
    firstNameInput.style.boxShadow = "none";
  }
}

lastNameInput.addEventListener("blur", blurLastName);
function blurLastName() {
  let lastNameValue = lastNameInput.value;

  if (lastNameValue) {
    lastNameSpan.style.visibility = "hidden";
    lastNameInput.style.boxShadow = "none";
  }
}
