// set up the highway constructor
function Highway() {
  this.vehicles = [];
}

//handling svg & paths
const actionSvg = document.querySelector("#svg-picture");

const carPicture = actionSvg.querySelector("#car");
carPicture.style.visibility = "hidden";
const truckPicture = actionSvg.querySelector("#truck");
truckPicture.style.visibility = "hidden";
const busPicture = actionSvg.querySelector("#bus");
busPicture.style.visibility = "hidden";

function displayVehicle(vehicle) {
  vehicle.style.visibility = "visible";
}

function hideVehicle(vehicle) {
  vehicle.style.visibility = "hidden";
}

function driveOnSpeedHighway(vehicle) {
  const translateYValue = "-1200px";
  let vehiclePicture;

  // Show the picture based on the vehicle type
  if (vehicle.type === "Car") {
    vehiclePicture = carPicture;
  } else if (vehicle.type === "Truck") {
    vehiclePicture = truckPicture;
  } else if (vehicle.type === "Bus") {
    vehiclePicture = busPicture;
  }
  displayVehicle(vehiclePicture);
  vehiclePicture.style.transition = "transform 3s ease-in-out";
  vehiclePicture.style.transform = `translateY(${translateYValue})`;

  setTimeout(() => {
    vehiclePicture.style.transform = "none";
    vehiclePicture.style.transition = "none";
    hideVehicle(vehiclePicture);
  }, 5000);
}

function driveOnPayedHighway(vehicle) {
  const translateYValue = "-650px";
  let vehiclePicture;
  // Show the picture based on the vehicle type
  if (vehicle.type === "Car") {
    vehiclePicture = carPicture;
  } else if (vehicle.type === "Truck") {
    vehiclePicture = truckPicture;
  } else if (vehicle.type === "Bus") {
    vehiclePicture = busPicture;
  }
  displayVehicle(vehiclePicture);
  vehiclePicture.style.transition = `transform 3s ease-in-out `;
  vehiclePicture.style.transform = `translateY(${translateYValue})`;
  setTimeout(() => {
    vehiclePicture.style.transform = `translate(600px, -1000px) `;
  }, 1500);

  setTimeout(() => {
    vehiclePicture.style.transform = "none";
    vehiclePicture.style.transition = "none";
    hideVehicle(vehiclePicture); // Reset transition property
  }, 5000);
}

function driveOnGenericHighway(vehicle) {
  const translateYValue = "-750px";
  let vehiclePicture;

  if (vehicle.type === "Car") {
    vehiclePicture = carPicture;
  } else if (vehicle.type === "Truck") {
    vehiclePicture = truckPicture;
  } else if (vehicle.type === "Bus") {
    vehiclePicture = busPicture;
  }
  displayVehicle(vehiclePicture);
  vehiclePicture.style.transition = `transform 3s ease-in-out `;
  vehiclePicture.style.transform = `translateY(${translateYValue})`;
  setTimeout(() => {
    vehiclePicture.style.transform = `translate(-750px, -700px)`;
  }, 2000);

  setTimeout(() => {
    vehiclePicture.style.transform = "none";
    vehiclePicture.style.transition = "none";
    hideVehicle(vehiclePicture);
  }, 5000);
}

function brokenVehicle(vehicle) {
  let vehiclePicture;

  if (vehicle.type === "Car") {
    vehiclePicture = carPicture;
  } else if (vehicle.type === "Truck") {
    vehiclePicture = truckPicture;
  } else if (vehicle.type === "Bus") {
    vehiclePicture = busPicture;
  }
  vehiclePicture.classList.add("broken-vehicle");
  displayVehicle(vehiclePicture);
  setTimeout(() => {
    vehiclePicture.classList.remove("broken-vehicle");
    hideVehicle(vehiclePicture);
  }, 5000);
}

// each highway requires a method that allows vehicles on it
Highway.prototype.allowVehicle = function (vehicle) {
  if (vehicle instanceof Vehicle && vehicle.isWorking === true) {
    this.vehicles.push(vehicle);
  }
};

// create a SpeedHighway - only cars that can go on a highway and also can go past 110 can go here.
function SpeedHighway(speedLimit) {
  Highway.call(this);
  this.speedLimit = speedLimit || 110;
}

SpeedHighway.prototype = Object.create(Highway.prototype);
SpeedHighway.prototype.constructor = SpeedHighway;

// change the allowVehicle method
SpeedHighway.prototype.allowVehicle = function (vehicle) {
  if (
    vehicle instanceof Vehicle &&
    vehicle.maxSpeed >= this.speedLimit &&
    vehicle.isWorking === true
  ) {
    Highway.prototype.allowVehicle.call(this, vehicle);
    return true;
  }
};

// create PayedSpeedHighway - only cars that can go on a highway, pass the speed limit, and whose drivers have enough money to pay the toll can go
function PayedSpeedHighway(speedLimit, tollRate) {
  SpeedHighway.call(this, speedLimit);
  this.tollRate = tollRate || 0.05;
}

PayedSpeedHighway.prototype = Object.create(SpeedHighway.prototype);
PayedSpeedHighway.prototype.constructor = PayedSpeedHighway;

// change allowVehicle
PayedSpeedHighway.prototype.allowVehicle = function (vehicle) {
  if (
    vehicle instanceof Vehicle &&
    vehicle.maxSpeed >= this.speedLimit &&
    vehicle.isWorking &&
    this.canPayToll(vehicle)
  ) {
    Highway.prototype.allowVehicle.call(this, vehicle);
    this.collectToll(vehicle);
    return true;
  }
};

// check if the driver can pay the toll
PayedSpeedHighway.prototype.canPayToll = function (vehicle) {
  const toll = vehicle.weight * this.tollRate;
  return vehicle.driver.balance >= toll;
};

// collect toll
PayedSpeedHighway.prototype.collectToll = function (vehicle) {
  const toll = vehicle.weight * this.tollRate;
  console.log(`Toll collected for ${vehicle.brand}: $${toll.toFixed(0)}`);
  vehicle.driver.balance -= toll;
};

// Driver
function Driver(name, balance = 0) {
  this.name = name;
  this.balance = balance;
}

// generic vehicle
function Vehicle(type, brand, weight, maxSpeed, isWorking, driver) {
  this.type = type;
  this.brand = brand;
  this.weight = weight;
  this.maxSpeed = maxSpeed;
  this.isWorking = isWorking;
  this.driver = driver;

  this.drive = function () {
    if (this.isWorking && this.driver) {
      console.log(`${this.driver.name} is driving.`);
    } else {
      console.log(`This vehicle is not moving.`);
    }
  };
}

// car
function Car(brand, model, weight, maxSpeed, isWorking, driver) {
  Vehicle.call(this, "Car", brand, weight, maxSpeed, isWorking, driver);
  this.model = model;
}

Car.prototype = Object.create(Vehicle.prototype);
Car.prototype.constructor = Car;

// bus
function Bus(brand, weight, maxSpeed, isWorking, driver, nrOfPassengers) {
  Vehicle.call(this, "Bus", brand, weight, maxSpeed, isWorking, driver);
  this.nrOfPassengers = nrOfPassengers;
}

Bus.prototype = Object.create(Vehicle.prototype);
Bus.prototype.constructor = Bus;

function Truck(brand, weight, maxSpeed, isWorking, driver, load) {
  Vehicle.call(this, "Truck", brand, weight, maxSpeed, isWorking, driver);
  this.load = load;
}

Truck.prototype = Object.create(Vehicle.prototype);
Truck.prototype.constructor = Truck;

const john = new Driver("John", 100);
const dean = new Driver("Dean", 10);
const sam = new Driver("Sam", 250);
const amara = new Driver("Amara", 15);

// const model3 = new Car("Tesla", "Model 3", 2149, 225, true, john);
// const impala = new Car("Chevrolet", "Impala 1967", 1740, 209, true, dean);
// const charger = new Car("Dodge", "Charger 2006", 1955, 280, true, sam);

const genericHighway = new Highway();
const speedHighway = new SpeedHighway(120);
const payedSpeedHighway = new PayedSpeedHighway(150, 0.05);

function assignToHighway(vehicle) {
  // Hide all vehicle pictures
  carPicture.style.visibility = "hidden";
  truckPicture.style.visibility = "hidden";
  busPicture.style.visibility = "hidden";

  if (payedSpeedHighway.allowVehicle(vehicle)) {
    driveOnPayedHighway(vehicle);
    console.log(`${vehicle.brand} is assigned to the Payed Speed Highway.`);
  } else if (speedHighway.allowVehicle(vehicle)) {
    driveOnSpeedHighway(vehicle);
    console.log(`${vehicle.brand} is assigned to the Speed Highway.`);
  } else if (vehicle.isWorking) {
    genericHighway.allowVehicle(vehicle);
    driveOnGenericHighway(vehicle);
    console.log(`${vehicle.brand} is assigned to Generic Highway.`);
  } else {
    brokenVehicle(vehicle);
    console.log(`${vehicle.brand} cannot drive.`);
  }
}

//the dom manipulation part
let driversList = [john, dean, sam, amara];

function addNewDriver() {
  let driverName = document.getElementById("driver-name").value;
  let driverBalance = document.getElementById("driver-balance").value;

  if (driverName) {
    let newDriver = new Driver(driverName, driverBalance);

    driversList.push(newDriver);

    document.getElementById("driver-name").value = "";
    document.getElementById("driver-balance").value = "";

    updateSelectOptions();
    updateBusDriverOptions();
    updateTruckDriverOptions();
  } else {
    alert("Please provide a name for your driver");
  }
}

updateSelectOptions();
updateBusDriverOptions();
updateTruckDriverOptions();

function updateSelectOptions() {
  let selectDriverSelector = document.getElementById("select-driver");

  selectDriverSelector.innerHTML = "";

  // Add each driver as an option
  driversList.forEach((driver) => {
    let option = document.createElement("option");
    option.text = driver.name;
    option.value = driver.name;
    selectDriverSelector.add(option);
  });
}

function updateBusDriverOptions() {
  let selectDriverSelector = document.getElementById("select-bus-driver");

  selectDriverSelector.innerHTML = "";

  // Add each driver as an option
  driversList.forEach((driver) => {
    let option = document.createElement("option");
    option.text = driver.name;
    option.value = driver.name;
    selectDriverSelector.add(option);
  });
}

function updateTruckDriverOptions() {
  let selectDriverSelector = document.getElementById("select-truck-driver");

  selectDriverSelector.innerHTML = "";

  // Add each driver as an option
  driversList.forEach((driver) => {
    let option = document.createElement("option");
    option.text = driver.name;
    option.value = driver.name;
    selectDriverSelector.add(option);
  });
}

// Event listener for the "Add new driver" button
document
  .getElementById("new-driver-button")
  .addEventListener("click", addNewDriver);

function createAndAssignCar() {
  // Get input elements for the car
  let carBrandInput = document.getElementById("car-brand");
  let carModelInput = document.getElementById("car-model");
  let carWeightInput = document.getElementById("car-weight");
  let carMaxSpeedInput = document.getElementById("car-maxSpeed");
  let isCarWorkingInput = document.getElementById("car-isWorking");
  let selectDriverInput = document.getElementById("select-driver");

  // Get values from the input elements
  let carBrand = carBrandInput.value;
  let carModel = carModelInput.value;
  let carWeight = carWeightInput.value;
  let carMaxSpeed = carMaxSpeedInput.value;
  let isCarWorking = isCarWorkingInput.checked;
  let selectedDriver = selectDriverInput.value;

  // Validate input values if required
  if (carBrand && carModel && carMaxSpeed && selectedDriver) {
    let selectedDriverObj = driversList.find(
      (driver) => driver.name === selectedDriver
    );

    let newCar = new Car(
      carBrand,
      carModel,
      carWeight,
      carMaxSpeed,
      isCarWorking,
      selectedDriverObj
    );

    assignToHighway(newCar);
    displayVehicle(carPicture);

    carBrandInput.value = "";
    carModelInput.value = "";
    carWeightInput.value = "";
    carMaxSpeedInput.value = "";
    isCarWorkingInput.checked = true;
    selectDriverInput.value = "";
  } else {
    alert("Please fill in all car details and select a driver.");
  }
}

document
  .getElementById("new-car-button")
  .addEventListener("click", createAndAssignCar);

function createAndAssignBus() {
  // Get input elements for the car
  let busBrandInput = document.getElementById("bus-brand");
  let busWeightInput = document.getElementById("bus-weight");
  let busMaxSpeedInput = document.getElementById("bus-maxSpeed");
  let isBusWorkingInput = document.getElementById("bus-isWorking");
  let busNrOfPassengersInput = document.getElementById("bus-nrOfPassanger");
  let selectDriverInput = document.getElementById("select-bus-driver");

  // Get values from the input elements
  let busBrand = busBrandInput.value;
  let busWeight = busWeightInput.value;
  let busMaxSpeed = busMaxSpeedInput.value;
  let isBusWorking = isBusWorkingInput.checked;
  let busNrOfPassengers = busNrOfPassengersInput.checked;
  let selectedDriver = selectDriverInput.value;

  // Validate input values if required
  if (busBrand && busWeight && busMaxSpeed && selectedDriver) {
    let selectedDriverObj = driversList.find(
      (driver) => driver.name === selectedDriver
    );

    let newBus = new Bus(
      busBrand,
      busWeight,
      busMaxSpeed,
      isBusWorking,
      selectedDriverObj,
      busNrOfPassengers
    );

    assignToHighway(newBus);

    busBrandInput.value = "";
    busWeightInput.value = "";
    busMaxSpeedInput.value = "";
    busNrOfPassengersInput.value = "";
    isBusWorkingInput.checked = true;
    selectDriverInput.value = "";
  } else {
    alert("Please fill in all bus details and select a driver.");
  }
}

document
  .getElementById("new-bus-button")
  .addEventListener("click", createAndAssignBus);

function createAndAssignTruck() {
  // Get input elements for the car
  let truckBrandInput = document.getElementById("truck-brand");
  let truckWeightInput = document.getElementById("truck-weight");
  let truckMaxSpeedInput = document.getElementById("truck-maxSpeed");
  let isTruckWorkingInput = document.getElementById("truck-isWorking");
  let truckLoadInput = document.getElementById("truck-load");
  let selectDriverInput = document.getElementById("select-truck-driver");

  // Get values from the input elements
  let truckBrand = truckBrandInput.value;
  let truckWeight = truckWeightInput.value;
  let truckMaxSpeed = truckMaxSpeedInput.value;
  let truckLoad = truckLoadInput.value;
  let isTruckWorking = isTruckWorkingInput.checked;
  let selectedDriver = selectDriverInput.value;

  // Validate input values if required
  if (truckBrand && truckWeight && truckMaxSpeed && selectedDriver) {
    let selectedDriverObj = driversList.find(
      (driver) => driver.name === selectedDriver
    );

    let newTruck = new Truck(
      truckBrand,
      truckWeight,
      truckMaxSpeed,
      isTruckWorking,
      selectedDriverObj,
      truckLoad
    );

    assignToHighway(newTruck);
    displayVehicle(truckPicture);

    truckBrandInput.value = "";
    truckWeightInput.value = "";
    truckMaxSpeedInput.value = "";
    isTruckWorking.checked = true;
    truckLoadInput.value = "";
    selectDriverInput.value = "";
  } else {
    alert("Please fill in all bus details and select a driver.");
  }
}

document
  .getElementById("new-truck-button")
  .addEventListener("click", createAndAssignTruck);

const carFieldset = document.getElementById("car-fieldset");
const busFieldset = document.getElementById("bus-fieldset");
const truckFieldset = document.getElementById("truck-fieldset");

const vehicleTypeSelect = document.getElementById("vehicle-type");

//initial state
carFieldset.style.display = "block";
busFieldset.style.display = "none";
truckFieldset.style.display = "none";

vehicleTypeSelect.addEventListener("change", function () {
  // show the selected fieldset
  const selectedOption = vehicleTypeSelect.value;

  if (selectedOption === "car") {
    carFieldset.style.display = "block";
    busFieldset.style.display = "none";
    truckFieldset.style.display = "none";
  } else if (selectedOption === "bus") {
    busFieldset.style.display = "block";
    carFieldset.style.display = "none";
    truckFieldset.style.display = "none";
  } else if (selectedOption === "truck") {
    truckFieldset.style.display = "block";
    busFieldset.style.display = "none";
    carFieldset.style.display = "none";
  }
});
