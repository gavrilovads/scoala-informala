const allCharacterButton = document.querySelector("#all-character-button");
const allLocationButton = document.querySelector("#all-location-button");
const allEpisodeButton = document.querySelector("#all-episode-button");

const clearAllCharactersButton = document.querySelector(
  "#clear-characters-button"
);
const clearAllLocationsButton = document.querySelector(
  "#clear-locations-button"
);
const clearAllEpisodesButton = document.querySelector("#clear-episodes-button");

const allCharacterUrl = "https://rickandmortyapi.com/api/character";
const allLocationUrl = "https://rickandmortyapi.com/api/location";
const allEpisodeUrl = "https://rickandmortyapi.com/api/episode";

const characterContainer = document.querySelector("#character-container");
const locationContainer = document.querySelector("#location-container");
const episodeContainer = document.querySelector("#episode-container");

const specificCharacterContainer = document.querySelector("#character-results");

const errorMessage =
  "Sometimes Science Is More Art Than Science. Whatever ID you tried, try again... Hopefully this time you fail better.";

//make a function that would clear all child divs;
function clearDiv(selectedDiv) {
  selectedDiv.textContent = "";
  selectedDiv.classList.remove("error");
  while (selectedDiv.hasChildNodes()) {
    selectedDiv.removeChild(selectedDiv.firstChild);
  }
  selectedDiv.classList.remove("add-scroll");
}

function hideButton(selectedButton) {
  selectedButton.style.visibility = "hidden";
}

//make a function that would print the error message;
function displayErrorMessage(selectedDiv, errorMessage) {
  selectedDiv.textContent = `${errorMessage}`;
  selectedDiv.classList.add("error");
}

//make a function to disable buttons
function disableButtons() {
  allCharacterButton.disabled = true;
  allLocationButton.disabled = true;
  allEpisodeButton.disabled = true;
}
//make a function to enable buttons
function enableButtons() {
  setTimeout(function () {
    allCharacterButton.disabled = false;
    allLocationButton.disabled = false;
    allEpisodeButton.disabled = false;
  }, 3000);
}

function disableThisButton(button) {
  button.disabled = true;
}

function enableThisButton(button) {
  setTimeout(function () {
    button.disabled = false;
  }, 3000);
}

// fetch results by url;
function fetchResults(urlLink) {
  return new Promise(function (resolve, reject) {
    fetch(urlLink, {
      method: "GET",
      // mode: "no-cors",
    })
      .then(function (response) {
        if (!response.ok) {
          console.error(`Error during fetch> ${response.status}`);
          reject(new Error(`Error during fetch", ${response.status}`));
        } else {
          return response.json();
        }
      })
      .then(function (goodResult) {
        if (!goodResult.error) {
          resolve(goodResult);
        } else {
          reject(goodResult);
        }
      })
      .catch(function (error) {
        console.error(error);
        reject(error);
      });
  });
}

//get results even if id is inputed
function getSpecificResult(urlLink, selectedId) {
  let specificReference = selectedId?.value || selectedId || "";
  let newUrl = `${urlLink}/${specificReference}`;
  return fetchResults(newUrl);
}

// get all results
function getAllResults(urlLink) {
  return fetchResults(urlLink)
    .then(function (results) {
      if (results.info) {
        const count = results.info.count;
        const newUrl =
          `${urlLink}/` +
          Array.from({ length: count }, (_, i) => i + 1).join(",");

        return fetchResults(newUrl);
      }
    })
    .catch(function (error) {
      console.error("Error while getting results", error);
      throw error;
    });
}

//character relates section
function characterStatusFunction(charStatus, picture, element) {
  picture.classList.add("character-status");
  if (charStatus === "Alive") {
    picture.classList.add("alive");
  } else if (charStatus === "Dead") {
    picture.classList.add("dead");
    element.classList.add("card-dead");
  } else {
    picture.classList.add("mistery-status");
  }
}

function characterGenderFunction(charGender, element) {
  element.classList.add("character-gender");
  const icon = document.createElement("i");
  if (charGender == "Male") {
    element.classList.add("male");
    icon.classList.add("fa-solid", "fa-mars");
  } else if (charGender == "Female") {
    element.classList.add("female");
    icon.classList.add("fa-solid", "fa-venus");
  } else {
    element.classList.add("uncertain");
  }
  element.appendChild(icon);
}

function createChildElement(parent, childType, className) {
  const childElement = parent.appendChild(document.createElement(childType));
  childElement.classList.add(className);
  return childElement;
}

//deleteThisCharacter
function deleteThisElement(divId) {
  let divToRemove = document.getElementById(divId);
  divToRemove.parentNode.removeChild(divToRemove);
}

function createCharacterCard(
  spaceToDisplay,
  charName,
  charSpecies,
  charGender,
  charType,
  originName,
  locationName,
  charStatus,
  imageUrl,
  characterId
) {
  spaceToDisplay.className = "character-result-div";
  const characterCard = createChildElement(
    spaceToDisplay,
    "div",
    "specific-character-results"
  );

  // Add delete button
  const deleteButton = createChildElement(
    characterCard,
    "button",
    "delete-button"
  );

  deleteButton.classList.add("fa-solid");
  deleteButton.classList.add("fa-trash");

  characterCard.id = `${characterId}`;
  const characterNameDiv = createChildElement(
    characterCard,
    "div",
    "character-name"
  );
  characterNameDiv.textContent = `${charName}`;

  const characterSpeciesDiv = createChildElement(
    characterCard,
    "div",
    "character-species"
  );
  characterSpeciesDiv.textContent = `${charSpecies}`;

  characterGenderFunction(charGender, characterNameDiv);

  const characterTypeDiv = createChildElement(
    characterCard,
    "div",
    "character-type"
  );
  characterTypeDiv.textContent = `${charType}`;

  const characterOriginDiv = createChildElement(
    characterCard,
    "div",
    "character-origin"
  );
  const sourceTreeIcon = createChildElement(
    characterOriginDiv,
    "i",
    "fa-solid"
  );
  sourceTreeIcon.classList.add("fa-bullseye");
  sourceTreeIcon.fontSize = "1rem";

  const characterOriginText = createChildElement(
    characterOriginDiv,
    "p",
    "origin-text"
  );
  characterOriginText.textContent = `${originName}`;

  const characterLocationDiv = createChildElement(
    characterCard,
    "div",
    "character-location"
  );
  const locationIcon = createChildElement(
    characterLocationDiv,
    "i",
    "fa-solid"
  );
  locationIcon.classList.add("fa-location-dot");
  locationIcon.fontSize = "1rem";

  const characterLocationText = createChildElement(
    characterLocationDiv,
    "p",
    "character-location"
  );

  const gapPlaceholder = createChildElement(
    characterCard,
    "div",
    "gap-placeholder-character"
  );

  characterLocationText.textContent = `${locationName}`;

  const imgDiv = createChildElement(
    characterCard,
    "div",
    "character-image-div"
  );
  const img = createChildElement(imgDiv, "img", "api-result-image");
  img.src = imageUrl;

  characterStatusFunction(charStatus, img, characterCard);

  deleteButton.addEventListener("click", function () {
    deleteThisElement(characterId);
  });
}

function printSpecificCharacterResults(
  urlLink,
  selectedId,
  spaceToDisplay,
  resultSection
) {
  clearDiv(spaceToDisplay);
  resultSection.classList.remove("add-scroll");

  const singleCharacterContainer = createChildElement(
    spaceToDisplay,
    "div",
    "single-character-container"
  );

  getSpecificResult(urlLink, selectedId)
    .then(function (characterResult) {
      if (!characterResult.error) {
        const specificName = `${characterResult.name}    `;
        const specificSpecies = `${characterResult.species}`;
        const specificGender = `${characterResult.gender}`;
        const specificType = `${characterResult.type}`;
        const specificOrigin = `${characterResult.origin.name}`;
        const specificLocation = `${characterResult.location.name}`;
        const specificImage = characterResult.image;
        const returnedStatus = characterResult.status;
        const specificId = `${characterResult.id}`;

        createCharacterCard(
          spaceToDisplay,
          specificName,
          specificSpecies,
          specificGender,
          specificType,
          specificOrigin,
          specificLocation,
          returnedStatus,
          specificImage,
          specificId
        );

        selectedId.value = "";
      } else {
        throw new Error("There is an error!", characterResult.error);
      }
    })
    .catch(function (error) {
      displayErrorMessage(spaceToDisplay, errorMessage);
      console.error(error);
    });
}

function printAllCharacterResults(urlLink, spaceToDisplay, resultSection) {
  disableButtons();
  disableThisButton(clearAllCharactersButton);
  clearDiv(spaceToDisplay);
  resultSection.classList.add("add-scroll");

  return getAllResults(urlLink)
    .then(function (allResults) {
      for (let i = 0; i < allResults.length; i++) {
        const specificName = `${allResults[i].name}    `;
        const specificSpecies = `${allResults[i].species}`;
        const specificGender = `${allResults[i].gender}`;
        const specificType = `${allResults[i].type}`;
        const specificOrigin = `${allResults[i].origin.name}`;
        const specificLocation = `${allResults[i].location.name}`;
        const specificImage = allResults[i].image;
        const returnedStatus = allResults[i].status;
        const specificId = `${allResults[i].id}`;

        const allCharactersContainer = createChildElement(
          spaceToDisplay,
          "div",
          "multi-character-container"
        );
        createCharacterCard(
          allCharactersContainer,
          specificName,
          specificSpecies,
          specificGender,
          specificType,
          specificOrigin,
          specificLocation,
          returnedStatus,
          specificImage,
          specificId
        );
      }
    })
    .catch(function (error) {
      displayErrorMessage(spaceToDisplay, errorMessage);
      console.error(error);
    })
    .finally(function () {
      enableButtons();
      enableThisButton(clearAllCharactersButton);
      clearAllCharactersButton.style.visibility = "visible";
    });
}

//location related section
function isDeserted(nrOfResidents, element) {
  const isDeserted = nrOfResidents.length === 0;

  element.src = isDeserted ? "./Images/deserted.svg" : "./Images/planet.svg";

  if (isDeserted) {
    element.classList.add("deserted");
  } else {
    element.classList.remove("deserted");
  }
}

function createLocationCard(
  spaceToDisplay,
  locationName,
  locationDimension,
  locationType,
  locationResidents,
  locationId
) {
  spaceToDisplay.className = "location-result-div";

  const locationCard = createChildElement(
    spaceToDisplay,
    "div",
    "location-card"
  );

  const locationCardContent = createChildElement(
    locationCard,
    "div",
    "specific-location-content"
  );

  locationCard.id = `${locationId}`;

  const cardPicture = createChildElement(
    locationCardContent,
    "img",
    "card-picture"
  );
  isDeserted(locationResidents, cardPicture);

  const cardContent = createChildElement(
    locationCardContent,
    "div",
    "card-content"
  );

  const locationNameDiv = createChildElement(
    cardContent,
    "div",
    "location-name"
  );
  locationNameDiv.textContent = `${locationName}`;

  const twoColumns = createChildElement(cardContent, "div", "two-columns");
  const columnOne = createChildElement(twoColumns, "div", "column-one");

  const locationDimensionDiv = createChildElement(
    columnOne,
    "div",
    "location-dimension"
  );
  locationDimensionDiv.textContent = `${locationDimension}`;
  const locationTypeDiv = createChildElement(columnOne, "div", "location-type");
  locationTypeDiv.textContent = `${locationType}`;

  const columnTwo = createChildElement(twoColumns, "div", "column-two");
  const locationResidentsDiv = createChildElement(
    columnTwo,
    "div",
    "residents-div"
  );

  const residentDetails = createChildElement(
    locationResidentsDiv,
    "details",
    "details-section"
  );
  const residentSummary = createChildElement(
    residentDetails,
    "summary",
    "summary-section"
  );

  residentSummary.textContent = `${locationResidents.length} resident(s)`;
  const locationResidentsList = createChildElement(
    residentDetails,
    "ul",
    "residents-list"
  );

  residentSummary.addEventListener("click", function () {
    if (locationResidentsList.children.length === 0) {
      const residentPromises = [];

      for (let i = 0; i < locationResidents.length; i++) {
        const newResident = createChildElement(
          locationResidentsList,
          "li",
          "list-item"
        );
        const linkToResident = locationResidents[i];
        const getNewResident = getSpecificResult(linkToResident, "")
          .then(function (residentResult) {
            newResident.textContent = `${residentResult.name}  `;
            characterGenderFunction(residentResult.gender, newResident);
          })
          .catch(function (error) {
            console.error(`Error while fetching`);
          });
        residentPromises.push(getNewResident);
      }

      Promise.all(residentPromises).then(function () {
        if (locationResidents.length > 6) {
          locationResidentsList.classList.add("add-scroll");
        }
      });
    }
  });

  if (locationResidents.length === 0) {
    const noLocationResidents = locationResidentsDiv.appendChild(
      document.createElement("div")
    );
    noLocationResidents.textContent = "This looks deserted.";
  }
}

function printSpecificLocationResults(
  urlLink,
  selectedId,
  spaceToDisplay,
  resultSection
) {
  clearDiv(spaceToDisplay);
  resultSection.classList.remove("add-scroll");
  const oneLocationContainer = spaceToDisplay.appendChild(
    document.createElement("div")
  );
  oneLocationContainer.className = "single-location-container";
  getSpecificResult(urlLink, selectedId)
    .then(function (locationResults) {
      if (!locationResults.error) {
        const thisLocationName = `${locationResults.name}`;
        const thisLocationDimension = `${locationResults.dimension}`;
        const thisLocationType = `${locationResults.type}`;
        const thisLocationResidents = locationResults.residents;
        const thisLocationId = `loc_${locationResults.id}`;

        createLocationCard(
          spaceToDisplay,
          thisLocationName,
          thisLocationDimension,
          thisLocationType,
          thisLocationResidents,
          thisLocationId
        );
        selectedId.value = "";
      } else {
        throw new Error(`There is an error!`);
      }
    })
    .catch(function (error) {
      displayErrorMessage(spaceToDisplay, errorMessage);
      console.error(error);
    });
}

function printAllLocationResults(urlLink, spaceToDisplay, resultSection) {
  disableButtons();
  disableThisButton(clearAllLocationsButton);
  clearDiv(spaceToDisplay);
  resultSection.classList.add("add-scroll");

  getAllResults(urlLink)
    .then(function (allResults) {
      const allLocationContainer = spaceToDisplay.appendChild(
        document.createElement("div")
      );
      allLocationContainer.className = "multi-location-container";

      for (let i = 0; i < allResults.length; i++) {
        let thisLocationName = allResults[i].name;
        let thisLocationDimension = allResults[i].dimension;
        let thisLocationType = allResults[i].type;
        let thisLocationResidents = allResults[i].residents;
        let thisLocationId = `loc_${allResults[i].id}`;

        createLocationCard(
          allLocationContainer,
          thisLocationName,
          thisLocationDimension,
          thisLocationType,
          thisLocationResidents,
          thisLocationId
        );
      }
    })
    .catch(function (error) {
      displayErrorMessage(spaceToDisplay, errorMessage);
      console.error(error);
    })
    .finally(function () {
      enableButtons();
      enableThisButton(clearAllLocationsButton);
      clearAllLocationsButton.style.visibility = "visible";
    });
}

//episode related section

function createEpisodeCard(
  spaceToDisplay,
  episodeName,
  episode,
  episodeAirDate,
  episodeCharacters,
  episodeId
) {
  spaceToDisplay.className = "episode-result-div";
  const episodeCard = createChildElement(spaceToDisplay, "div", "episode-card");
  const episodeCardContent = createChildElement(
    episodeCard,
    "div",
    "specific-episode-content"
  );

  const episodePicture = createChildElement(
    episodeCardContent,
    "img",
    "card-picture"
  );
  const cardContent = createChildElement(
    episodeCardContent,
    "div",
    "card-content"
  );
  const episodeNameDiv = createChildElement(cardContent, "div", "episode-name");
  episodeNameDiv.textContent = `${episodeName}`;
  const twoColumns = createChildElement(cardContent, "div", "two-columns");
  const columnOne = createChildElement(twoColumns, "div", "column-one");

  const episodeNumber = createChildElement(columnOne, "div", "episode");
  episodeNumber.textContent = `${episode}`;
  const episodeAirDateDiv = createChildElement(
    columnOne,
    "div",
    "air-date-div"
  );
  episodeAirDateDiv.textContent = `${episodeAirDate}`;
  const columnTwo = createChildElement(twoColumns, "div", "column-two");
  const episodeCharactersDiv = createChildElement(
    columnTwo,
    "div",
    "episode-characters-div"
  );
  episodeCard.id = `${episodeId}`;
  const gapPlaceholder = createChildElement(
    episodeCard,
    "div",
    "gap-placeholder-episode"
  );
  clearAllEpisodesButton.style.visibility = "visible";

  const characterDetails = createChildElement(
    episodeCharactersDiv,
    "details",
    "episode-character-details"
  );
  const episodeCharacterSummary = createChildElement(
    characterDetails,
    "summary",
    "episode-character-summary"
  );
  episodeCharacterSummary.textContent = `${episodeCharacters.length} character(s)`;
  const episodeCharactersList = createChildElement(
    characterDetails,
    "ul",
    "character-list"
  );

  episodeCharacterSummary.addEventListener("click", function () {
    if (episodeCharactersList.children.length === 0) {
      const characterPromises = [];

      for (let i = 0; i < episodeCharacters.length; i++) {
        const newCharacter = createChildElement(
          episodeCharactersList,
          "li",
          "list-element"
        );
        const linkToCharacter = episodeCharacters[i];
        const getNewCharacter = getSpecificResult(linkToCharacter, "")
          .then(function (characterResults) {
            newCharacter.textContent = `${characterResults.name}  `;
            const characterGender = characterResults.gender;
            characterGenderFunction(characterGender, newCharacter);
          })
          .catch(function (error) {
            console.error("Error fetching character details.");
          });
        characterPromises.push(getNewCharacter);
      }

      Promise.all(characterPromises).then(function () {
        if (episodeCharacters.length > 6) {
          episodeCharactersList.classList.add("add-scroll");
        }
      });
    }
  });

  if (episodeCharacters.length === 0) {
    const noCharacters = createChildElement(
      episodeCharactersDiv,
      "div",
      "number-of-characters"
    );
    noCharacters.textContent =
      "Somebody made a sloppy job putting this together. Or there were no characters.";
  }
}

function printSpecificEpisodeResult(
  urlLink,
  selectedId,
  spaceToDisplay,
  resultSection
) {
  clearDiv(spaceToDisplay);
  resultSection.classList.remove("add-scroll");
  const oneEpisodeContainer = spaceToDisplay.appendChild(
    document.createElement("div")
  );
  oneEpisodeContainer.className = "single-episode-container";
  getSpecificResult(urlLink, selectedId)
    .then(function (episodeResults) {
      if (!episodeResults.error) {
        const thisEpisodeName = `${episodeResults.name}`;
        const thisEpisode = `${episodeResults.episode}`;
        const thisEpisodeAirDate = `${episodeResults.air_date}`;
        const thisEpisodeCharacters = episodeResults.characters;
        const thisEpisodeId = `ep_${episodeResults.id}`;

        createEpisodeCard(
          spaceToDisplay,
          thisEpisodeName,
          thisEpisode,
          thisEpisodeAirDate,
          thisEpisodeCharacters,
          thisEpisodeId
        );
        selectedId.value = "";
      } else {
        throw new Error("There is an error!");
      }
    })
    .catch(function (error) {
      displayErrorMessage(spaceToDisplay, errorMessage);
      console.error(error);
    });
}

function printAllEpisodeResults(urlLink, spaceToDisplay, resultSection) {
  disableButtons();
  disableThisButton(clearAllEpisodesButton);
  clearDiv(spaceToDisplay);
  resultSection.classList.add("add-scroll");

  getAllResults(urlLink)
    .then(function (allResults) {
      const episodeContainer = createChildElement(
        spaceToDisplay,
        "div",
        "multi-episode-container"
      );

      for (let i = 0; i < allResults.length; i++) {
        const thisEpisodeName = `${allResults[i].name}`;
        const thisEpisode = `${allResults[i].episode}`;
        const thisEpisodeAirDate = `${allResults[i].air_date}`;
        const thisEpisodeCharacters = allResults[i].characters;
        const thisEpisodeId = `ep_${allResults[i].id}`;

        createEpisodeCard(
          episodeContainer,
          thisEpisodeName,
          thisEpisode,
          thisEpisodeAirDate,
          thisEpisodeCharacters,
          thisEpisodeId
        );
      }
    })
    .catch(function (error) {
      displayErrorMessage(spaceToDisplay, errorMessage);
      console.error(error);
    })
    .finally(function () {
      enableButtons();
      enableThisButton(clearAllEpisodesButton);
      clearAllEpisodesButton.style.visibility = "visible";
    });
}

//calling functions

function allCharacterButtonAction() {
  printAllCharacterResults(
    allCharacterUrl,
    characterContainer,
    characterContainer
  );
}

function printAllLocations() {
  printAllLocationResults(allLocationUrl, locationContainer, locationContainer);
}

function printAllEpisodes() {
  printAllEpisodeResults(allEpisodeUrl, episodeContainer, episodeContainer);
}

function clickRick() {
  clearDiv(characterContainer);
  hideButton(clearAllCharactersButton);
  printSpecificCharacterResults(
    allCharacterUrl,
    rickId,
    characterContainer,
    specificCharacterContainer
  );
}

allCharacterButton.addEventListener("click", allCharacterButtonAction);
allLocationButton.addEventListener("click", printAllLocations);
allEpisodeButton.addEventListener("click", printAllEpisodes);

//fun bonus

const rickButton = document.querySelector("#rick-picture");
const rickId = 1;

const mortyButton = document.querySelector("#morty-picture");
const mortyId = 2;

rickButton.addEventListener("click", clickRick);

mortyButton.addEventListener("click", function clickMorty() {
  printSpecificCharacterResults(
    allCharacterUrl,
    mortyId,
    characterContainer,
    specificCharacterContainer
  );
  hideButton(clearAllCharactersButton);
});

function clearCharacterResults() {
  clearDiv(characterContainer);
  hideButton(clearAllCharactersButton);
}

function clearLocationResults() {
  clearDiv(locationContainer);
  hideButton(clearAllLocationsButton);
}

function clearEpisodeResults() {
  clearDiv(episodeContainer);
  hideButton(clearAllEpisodesButton);
}

clearAllCharactersButton.addEventListener("click", clearCharacterResults);

clearAllLocationsButton.addEventListener("click", clearLocationResults);

clearAllEpisodesButton.addEventListener("click", clearEpisodeResults);
