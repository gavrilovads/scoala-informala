//my api key: const apiKey = '875910ad6c133a0246090e1113dbe428';

const currentWeather = document.querySelector("#weather-now");
const descriptionElement = document.querySelector(
  "#current-weather-description"
);
const iconContainer = document.querySelector("#current-weather-icon");
const feelsLikeContainer = document.querySelector("#feels-like-result");
const sunrise = document.querySelector("#surrise-time");
const sunset = document.querySelector("#sunset-time");
const currentTime = document.querySelector("#time-read");
const uvIndex = document.querySelector("#uv-index");
const pressure = document.querySelector("#pressure");
const hourlyForecastContainer = document.querySelector(".hourly-forecast");
async function getWeather() {
  try {
    const position = await getCurrentPosition();
    const { latitude, longitude } = position.coords;
    const apiKey = "875910ad6c133a0246090e1113dbe428";
    const url = `https://api.openweathermap.org/data/2.5/onecall?lat=${latitude}&lon=${longitude}&appid=${apiKey}&units=metric`;
    const response = await fetch(url);
    const data = await response.json();
    console.log(data);
    displayWeather(data);
  } catch (error) {
    console.error("Error fetching weather data:", error);
  }
}

function getCurrentPosition() {
  return new Promise((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(resolve, reject);
  });
}

function displayWeather(data) {
  const { current, hourly } = data;
  const description = current.weather[0].description;
  const temperature = Math.floor(current.temp);
  const feelsLike = Math.floor(current.feels_like);
  const rise_hour = new Date(current.sunrise * 1000);
  const set_hour = new Date(current.sunset * 1000);
  const current_time = new Date(current.dt * 1000);

  feelsLikeContainer.textContent = `${feelsLike}°C`;
  descriptionElement.textContent = `${description}`;
  currentWeather.textContent = `${temperature}°C`;
  sunrise.textContent = rise_hour.toLocaleTimeString("ro-RO");

  sunset.textContent = set_hour.toLocaleTimeString("ro-RO");

  currentTime.textContent = `@ ${current_time.toLocaleTimeString("ro-RO")}`;

  const currentWeatherIcon = current.weather[0].icon;
  iconContainer.src = `http://openweathermap.org/img/w/${currentWeatherIcon}.png`;

  uvIndex.textContent = current.uvi;
  pressure.textContent = current.pressure;

  const hourlyForecast = hourly.slice(0, 6);

  hourlyForecast.forEach((hour) => {
    const timestamp = new Date(hour.dt * 1000);
    const time = timestamp.toLocaleTimeString("ro-RO");
    const temp = Math.round(hour.temp);
    const weatherIcon = hour.weather[0].icon;
    iconUrl = `http://openweathermap.org/img/w/${weatherIcon}.png`;

    const hourDiv = document.createElement("div");
    hourDiv.classList.add("hour");
    hourDiv.innerHTML = `
            <p>${time}</p>
            <img src="${iconUrl}" alt="${hour.weather[0].description}">
            <p>${temp}°C</p>
        `;
    hourlyForecastContainer.appendChild(hourDiv);
  });
}

getWeather();
