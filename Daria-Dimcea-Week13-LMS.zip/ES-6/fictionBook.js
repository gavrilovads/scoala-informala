import Book from "./book.js";

export default class FictionBook extends Book {
  constructor(title, author, ISBN, genre) {
    super(title, author, ISBN);
    this.genre = genre;
  }

  displayInfo() {
    console.log(
      `title: ${this.title}, author: ${this.author}, ISBN: ${
        this.ISBN
      }, genre: ${this.genre}, borrowed: ${this.borrowed ? "Yes" : "No"}`
    );
  }
}
