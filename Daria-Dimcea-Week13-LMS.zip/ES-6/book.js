export default class Book {
  constructor(title, author, ISBN) {
    this.title = title;
    this.author = author;
    this.ISBN = ISBN;
    this.borrowed = false; // default to not borrowed
  }

  displayInfo() {
    console.log(
      `title: ${this.title}, author: ${this.author}, ISBN: ${
        this.ISBN
      }, borrowed: ${this.borrowed ? "Yes" : "No"}`
    );
  }
}
