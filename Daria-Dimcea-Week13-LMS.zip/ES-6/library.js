export default class Library {
  constructor(books, members) {
    this.books = [];
    this.members = [];
  }

  addBook(book) {
    const existingBook = this.books.find(
      (existingBook) => existingBook.title === book.title
    );

    if (existingBook) {
      throw new Error(`Book ${book.title} already exists in the library.`);
    }

    this.books.push(book);
    console.log(`${book.title} was added to the library.`);
  }

  addMember(member) {
    const existingMember = this.members.find(
      (existingMember) => existingMember.name === member.name
    );

    if (existingMember) {
      throw new Error(`Member ${member.name} already exists in the library.`);
    }

    this.members.push(member);
    console.log(`${member.name} joined the library.`);
  }
//ideally would check against an uniquie ID, but for this purpose chekcing against a name
  getBorrowedBooks(memberName) {
    const member = this.members.find((member) => member.name === memberName);
    return member ? member.borrowedBooks : [];
  }
//irl there can be multiple instances of any book available
  borrowBook(memberName, bookTitle) {
    const member = this.members.find((member) => member.name === memberName);
    const book = this.books.find((book) => book.title === bookTitle);

    if (!member || !book) {
      console.log("Member or book not found.");
      return;
    }

    if (book.borrowed) {
      console.log(`${bookTitle} is already borrowed by another member.`);
      return;
    }

    member.borrowBook(book);
    console.log(`${memberName} borrowed ${bookTitle}.`);
  }
}
