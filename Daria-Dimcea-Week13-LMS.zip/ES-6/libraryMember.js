export default class LibraryMember {
  constructor(name) {
    this.name = name;
    this.borrowedBooks = [];
  }
  borrowBook(book) {
    if (!book.borrowed) {
      this.borrowedBooks.push(book);
      book.borrowed = true;
    } else {
      console.log(
        `Sorry, ${book.title} is already borrowed by another member.`
      );
    }
  }
  returnBook(book) {
    const index = this.borrowedBooks.findIndex(
      (borrowedBook) => borrowedBook === book
    );

    if (index !== -1) {
      this.borrowedBooks.splice(index, 1);
      book.borrowed = false;
      console.log(`${this.name} returned ${book.title}.`);
    } else {
      console.log(
        `${this.name} does not have ${book.title} in their borrowed books.`
      );
    }
  }
}
