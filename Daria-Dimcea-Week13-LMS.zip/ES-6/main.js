import Book from "./book.js";
import FictionBook from "./fictionBook.js";
import Library from "./library.js";
import LibraryMember from "./libraryMember.js";

const getElement = (selector) => document.querySelector(selector);
const overlay = getElement("#overlay");

const displayBorrowedBooksModal = getElement("#displayBorrowedBooksModal");
const displayBorrowedBooksButton = getElement("#displayBorrowedBooksButton");
const displayMemberDropdown = getElement("#displayMemberDropdown");
const displayBorrowedBooksContainer = getElement(
  "#displayBorrowedBooksContainer"
);
const closeModal = getElement("#close-modal");

// book instances testing
const tooGood = new Book(
  "You're too good to feel this bad",
  "Nate Dallas",
  "0578643427"
);

const hpss = new FictionBook(
  "Harry Potter and the Sorcerer's stone",
  "J.K. Rowling",
  "9780439362139",
  "Fantasy"
);
const dune = new FictionBook("Dune", "Frank Herbert", "0441172719", "Sci-Fi");

// library instance
const library = new Library();
library.addBook(hpss);
library.addBook(dune);
library.addBook(tooGood);

// library member instances testing
const daria = new LibraryMember("Daria");
library.addMember(daria);

const addBookButton = getElement("#addBookButton");
const addBookPopover = getElement("#addBookPopover");
const addBookSubmitBtn = getElement("#addBookSubmit");

const addMemberButton = getElement("#addMemberButton");
const addMemberPopover = getElement("#addMemberPopover");
const addMemberSubmitBtn = getElement("#addMemberSubmit");

addMemberButton.addEventListener("click", () => {
  overlay.style.display = "block";
  addMemberPopover.style.display = "block";
});

addMemberSubmitBtn.addEventListener("click", handleAddMemberSubmit);

function handleAddMemberSubmit(event) {
  const getValue = (id) => getElement(id).value;
  const name = getValue("#name");

  try {
    if (name) {
      const newMember = new LibraryMember(name);

      library.addMember(newMember);

      const successMessageDiv = createMessageDiv(
        "success",
        `${newMember.name} joined the library.`
      );

      addMemberPopover.appendChild(successMessageDiv);

      setTimeout(() => {
        successMessageDiv.textContent = "";
      }, 1500);
    } else {
      throw new Error("Please provide a name.");
    }
  } catch (error) {
    const errorMessageDiv = createMessageDiv("error", error.message);

    addMemberPopover.appendChild(errorMessageDiv);

    setTimeout(() => {
      errorMessageDiv.textContent = "";
    }, 1500);
  }

  resetMemberInputField();
}

function resetMemberInputField() {
  const inputIds = ["#name"];

  inputIds.forEach((id) => {
    getElement(id).value = "";
  });
}

const closeMemberButton = addMemberPopover.querySelector("#close-member-modal");

closeMemberButton.addEventListener("click", () => {
  addMemberPopover.style.display = "none";
  overlay.style.display = "none";
});

addBookButton.addEventListener("click", () => {
  overlay.style.display = "block";
  addBookPopover.style.display = "block";
});

addBookSubmitBtn.addEventListener("click", handleAddBookSubmit);

function handleAddBookSubmit(event) {
  const getValue = (id) => getElement(id).value;
  const title = getValue("#title");
  const author = getValue("#author");
  const ISBN = getValue("#ISBN");
  const genre = getValue("#genre");

  try {
    if (title && author && ISBN) {
      const newBook =
        genre === "Fantasy" || genre === "Sci-Fi"
          ? new FictionBook(title, author, ISBN, genre)
          : new Book(title, author, ISBN);

      library.addBook(newBook);

      const successMessageDiv = createMessageDiv(
        "success",
        `${newBook.title} was successfully added to the library.`
      );

      addBookPopover.appendChild(successMessageDiv);

      setTimeout(() => {
        successMessageDiv.textContent = "";
      }, 1500);
    } else {
      throw new Error(
        "Please provide values for all required fields (Title, Author, ISBN)."
      );
    }
  } catch (error) {
    const errorMessageDiv = createMessageDiv("error", error.message);

    addBookPopover.appendChild(errorMessageDiv);

    setTimeout(() => {
      errorMessageDiv.textContent = "";
    }, 1500);
  }

  resetInputFields();
}
function createMessageDiv(className, message) {
  const messageDiv = document.createElement("div");
  messageDiv.classList.add(className);
  messageDiv.textContent = message;
  return messageDiv;
}

function resetInputFields() {
  const inputIds = ["#title", "#author", "#ISBN", "#genre"];

  inputIds.forEach((id) => {
    getElement(id).value = "";
  });

  getElement("#genre").value = "Fantasy";
}

function populateDropdown(dropdown, options) {
  dropdown.innerHTML = "";

  options.forEach((option, id) => {
    const optionElement = document.createElement("option");
    optionElement.value = option;
    optionElement.textContent = option;
    dropdown.appendChild(optionElement);
  });
}

const borrowBooksBtn = getElement("#borrowBooksButton");
const borrowBooksPopover = getElement("#borrowBooksPopover");
const borrowBooksSubmitBtn = getElement("#borrowBooksSubmit");
const borrowMemberDropdown = getElement("#borrowMember");
const borrowBookDropdown = getElement("#borrowBook");

borrowBooksBtn.addEventListener("click", () => {
  populateDropdown(
    borrowMemberDropdown,
    library.members.map((member) => member.name)
  );
  populateDropdown(
    borrowBookDropdown,
    library.books.map((book) => book.title)
  );

  borrowBooksPopover.style.display = "block";
  overlay.style.display = "block";
});

const closeButton = borrowBooksPopover.querySelector(".closeButton");

closeButton.addEventListener("click", () => {
  borrowBooksPopover.style.display = "none";
  overlay.style.display = "none";
});

const statusUpdate = document.createElement("div");
statusUpdate.id = "statusUpdate";
statusUpdate.textContent = "";
borrowBooksPopover.appendChild(statusUpdate);

borrowBooksSubmitBtn.addEventListener("click", () => {
  const memberName = borrowMemberDropdown.value;
  const bookTitle = borrowBookDropdown.value;
  const member = library.members.find((member) => member.name === memberName);
  const book = library.books.find((book) => book.title === bookTitle);
  statusUpdate.classList.remove("success", "error", "warning");

  if (member && book) {
    if (!book.borrowed) {
      member.borrowBook(book);
      console.log(`${memberName} borrowed ${bookTitle}.`);
      statusUpdate.textContent = `${bookTitle} was successfully borrowed by ${memberName}.`;
      statusUpdate.classList.add("success");
      setTimeout(() => {
        statusUpdate.textContent = "";
      }, 1500);
    } else {
      console.warn(`${bookTitle} is already borrowed by another member.`);
      statusUpdate.textContent = `${bookTitle} is already borrowed by another member.`;
      statusUpdate.classList.add("warning");
    }
  } else {
    statusUpdate.textContent = "Member or book not found.";
    console.log(`Member or book not found.`);
    statusUpdate.classList.add("error");
  }
});

function clearDiv(container) {
  while (container.firstChild) {
    container.removeChild(container.firstChild);
  }
}

const seeBorrowedBooksButton = getElement("#seeBorrowedBooks");
seeBorrowedBooksButton.addEventListener("click", () => {
  populateDropdown(
    displayMemberDropdown,
    library.members.map((member) => member.name)
  );
  displayBorrowedBooksModal.style.display = "block";
  overlay.style.display = "block";
});

displayBorrowedBooksButton.addEventListener("click", () => {
  const selectedMember = displayMemberDropdown.value;
  clearDiv(displayBorrowedBooksContainer);

  const member = library.members.find(
    (member) => member.name === selectedMember
  );

  if (member) {
    if (member.borrowedBooks.length > 0) {
      member.borrowedBooks.forEach((book) => {
        const bookCard = document.createElement("div");
        bookCard.classList.add("book-card");

        const titleDiv = document.createElement("div");
        titleDiv.textContent = `Title: ${book.title}`;
        bookCard.appendChild(titleDiv);

        const authorDiv = document.createElement("div");
        authorDiv.textContent = `Author: ${book.author}`;
        bookCard.appendChild(authorDiv);

        const isbnDiv = document.createElement("div");
        isbnDiv.textContent = `ISBN: ${book.ISBN}`;
        bookCard.appendChild(isbnDiv);

        if (book.genre) {
          const genreDiv = document.createElement("div");
          genreDiv.textContent = `Genre: ${book.genre}`;
          bookCard.appendChild(genreDiv);
        }

        displayBorrowedBooksContainer.appendChild(bookCard);
      });
    } else {
      const displayBorrowedBooksContainerError = createMessageDiv(
        "error",
        `No books borrowed by ${selectedMember}.`
      );
      displayBorrowedBooksContainer.appendChild(
        displayBorrowedBooksContainerError
      );
    }
  } else {
    const displayBorrowedBooksContainerError = createMessageDiv(
      "error",
      "Member not found."
    );
    console.log(`Member not found.`);
    displayBorrowedBooksContainer.appendChild(
      displayBorrowedBooksContainerError
    );
  }
});

closeModal.addEventListener("click", () => {
  displayBorrowedBooksContainer.innerHTML = "";
  displayBorrowedBooksModal.style.display = "none";
  overlay.style.display = "none";
});

const closeBookModal = getElement("#close-book-modal");
closeBookModal.addEventListener("click", () => {
  addBookPopover.style.display = "none";
  overlay.style.display = "none";
});

const samWinchester = new LibraryMember("Sam Winchester");
const deanWinchester = new LibraryMember("Dean Winchester");
const castiel = new LibraryMember("Castiel");
const rowenaMacLeod = new LibraryMember("Rowena MacLeod");
const crowley = new LibraryMember("Crowley");

library.addMember(samWinchester);
library.addMember(deanWinchester);
library.addMember(castiel);
library.addMember(rowenaMacLeod);
library.addMember(crowley);

const lotrBook1 = new FictionBook(
  "The Fellowship of the Ring",
  "J.R.R. Tolkien",
  "9780544003415",
  "Fantasy"
);
const lotrBook2 = new FictionBook(
  "The Two Towers",
  "J.R.R. Tolkien",
  "9780544003330",
  "Fantasy"
);
const lotrBook3 = new FictionBook(
  "The Return of the King",
  "J.R.R. Tolkien",
  "9780544338012",
  "Fantasy"
);
const lotrBook4 = new FictionBook(
  "The Hobbit",
  "J.R.R. Tolkien",
  "9780547928227",
  "Fantasy"
);
const lotrBook5 = new FictionBook(
  "The Silmarillion",
  "J.R.R. Tolkien",
  "9780544273442",
  "Fantasy"
);

// Create sci-fi books
const sciFiBook1 = new FictionBook(
  "The War of the Worlds",
  "H.G. Wells",
  "9780141439976",
  "Sci-Fi"
);
const sciFiBook2 = new FictionBook(
  "The Time Machine",
  "H.G. Wells",
  "9780451531571",
  "Sci-Fi"
);
const sciFiBook3 = new FictionBook(
  "The Invisible Man",
  "H.G. Wells",
  "9781503262114",
  "Sci-Fi"
);

const nonSciFiFantasyBook1 = new Book(
  "To Kill a Mockingbird",
  "Harper Lee",
  "0061120081"
);
const nonSciFiFantasyBook2 = new Book("1984", "George Orwell", "0451524934");
const nonSciFiFantasyBook3 = new Book(
  "Pride and Prejudice",
  "Jane Austen",
  "9780141439518"
);
const nonSciFiFantasyBook4 = new Book(
  "The Great Gatsby",
  "F. Scott Fitzgerald",
  "9780743273565"
);
const nonSciFiFantasyBook5 = new Book(
  "The Catcher in the Rye",
  "J.D. Salinger",
  "9780316769480"
);

library.addBook(lotrBook1);
library.addBook(lotrBook2);
library.addBook(lotrBook3);
library.addBook(lotrBook4);
library.addBook(lotrBook5);
library.addBook(sciFiBook1);
library.addBook(sciFiBook2);
library.addBook(sciFiBook3);
library.addBook(nonSciFiFantasyBook1);
library.addBook(nonSciFiFantasyBook2);
library.addBook(nonSciFiFantasyBook3);
library.addBook(nonSciFiFantasyBook4);
library.addBook(nonSciFiFantasyBook5);



document.addEventListener('keydown', function(event) {
  if (event.key === 'Escape') {

      addBookPopover.style.display = 'none';
      addMemberPopover.style.display = 'none';
      borrowBooksPopover.style.display = 'none';
      displayBorrowedBooksModal.style.display = 'none';
      overlay.style.display = 'none';
  }
});
