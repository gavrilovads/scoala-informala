//Write a function that can take in any number of arguments, and returns the sum of all of the arguments.
function sumAllArguments(...args) {
  return args.reduce((sum, arg) => sum + arg, 0);
}

console.log(sumAllArguments(1, 2, 3, 4, 5, "elefant"));
console.log(sumAllArguments(1));
console.log(sumAllArguments(1, 2, 3));

//Write a function that can take in any number of arguments (including numbers or strings), and returns the sum of only the numbers.
function sumAllNumbers(...args) {
  return args
    .filter((arg) => typeof arg === "number")
    .reduce((sum, num) => sum + num, 0);
}

console.log(sumAllNumbers(1, 2, 3, 4, 5, "elefant"));
console.log(sumAllNumbers(1));
console.log(sumAllNumbers(1, 2, 3));

//Write a function that takes in two arrays as arguments, and returns a single array that combines both (using the spread operator).
function combinedArrays(array1, array2) {
  return [...array1, ...array2];
}
const x = [1, "two", 3];
const y = ["five", 6, "seven"];
console.log(combinedArrays([1, 2, 3], [4, 5, "elefant"]));
console.log(combinedArrays(x, y));

//Write a function that takes in any amount of arguments, and returns the sum of every other argument
function sumEveryOtherArgument(...args) {
  return args
    .filter((_, index) => index % 2 === 0)
    .reduce((sum, arg) => sum + arg, 0);
}
console.log(sumEveryOtherArgument(1, 2, 3, 4, 5, "elefant"));
console.log(sumEveryOtherArgument(1));
console.log(sumEveryOtherArgument(1, 2, 3));

//Write a function that can take in any number of arguments, and returns an array of only the unique arguments.
function filterUniqueArguments(...args) {
  return [...new Set(args)];
}

console.log(filterUniqueArguments(1, 1, 1, 1, 9, 2, 3, 4, 5, "elefant"));
console.log(filterUniqueArguments(1, 3, 3, 4, 5));
console.log(filterUniqueArguments(1, 2, 3, 4, 4, 4, 7));

//Write a function that takes in any number of arrays as arguments and combines all of them into one array.

//this solution only combines the unique values
function combineAllArrays(...arrays) {
  return [...new Set([].concat(...arrays))];
}

console.log(
  combineAllArrays([1, 2, 3], [4, 5, "elefant"], ["elefant", 4, 5, 12])
);
console.log(combineAllArrays([1], [1], [10]));
console.log(combineAllArrays(1, 2, 3));
console.log(combineAllArrays(x, y, x, y, x, y));

//second solution as the requirement is not clear. combines all values, can get duplicates.
function allCombinedArrays(...arrays) {
  return [].concat(...arrays);
}

console.log(allCombinedArrays(x, y, x));
