const choiceRock='Rock';
const choicePaper='Paper';
const choiceScissors='Scissors';

const possibleDraws=[choiceRock, choicePaper, choiceScissors];

const rand1=Math.floor(Math.random()*possibleDraws.length);
const rand2=Math.floor(Math.random()*possibleDraws.length);

const winMessageComputer = 'Computer wins!';
const winMessageUser = 'User wins!';
const tieMessage = 'Tie!';

const computerResult = document.querySelector("#computer-result");
const userResult = document.querySelector("#user-result");
const gameResult =  document.querySelector("#game-result");
const getResultsButton = document.querySelector("#get-results");

function play(Computer, User) {
    console.log(`Computer choice: ${possibleDraws[rand1]}`);
    console.log(`User choice: ${possibleDraws[rand2]}`);
    const result = User-Computer; 

    if (result==0) {
    console.log(tieMessage);
    return tieMessage;

    } else if (result===1 || result===-2) {
        console.log(winMessageUser);
        return winMessageUser;
    } else {
        console.log(winMessageComputer);
        return winMessageComputer;
    }
};

let gameResultValue = play(rand1, rand2);

computerResult.textContent = `Computer choice: ${possibleDraws[rand1]}`;
userResult.textContent = `User choice: ${possibleDraws[rand2]}`;
gameResult.textContent = `${gameResultValue}`;

function viewResults(){
    window.location.reload();
}

getResultsButton.addEventListener("click", viewResults);



// simple version below, the refresh button would not work on this

// const choiceRock='Rock';
// const choicePaper='Paper';
// const choiceScrissors='Scrissors';

// const possibleDraws=[choiceRock, choicePaper, choiceScrissors];

// const rand1=possibleDraws[Math.floor(Math.random()*possibleDraws.length)];
// const rand2=possibleDraws[Math.floor(Math.random()*possibleDraws.length)];
// const winMessageComputer = 'Computer wins!';
// const winMessageUser = 'User wins!';
// const tieMessage = 'Tie!';


// function play(Computer, User) {
//     console.log(`Computer choice: ${Computer}`);
//     console.log(`User choice: ${User}`);

//     if (Computer == User) {
//     console.log(tieMessage);

//     } else if ((Computer == choiceRock && User == choiceScrissors) || (Computer == choicePaper && User==choiceRock) || (Computer==choiceScrissors && User==choicePaper)) {
//         console.log(winMessageComputer);
//     } else {
//         console.log(winMessageUser);
//     }
// };

// play(rand1, rand2);
