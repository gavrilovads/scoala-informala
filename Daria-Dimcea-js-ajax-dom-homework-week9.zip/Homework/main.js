const theMealUrl = "https://www.themealdb.com/api.php";
const theMealFilterUrl =
  "https://www.themealdb.com/api/json/v1/1/filter.php?i=";
const recipeUrl = "https://www.themealdb.com/api/json/v1/1/lookup.php?i=";
const youtubeEmbed = "https://www.youtube.com/embed/";

const searchRecipeButton = document.querySelector(
  "#search-by-ingredient-button"
);

const inputKeyword = document.querySelector("#search-by-ingredient-input");

const resultsContainer = document.querySelector(".search-results-container");
const cardsContainer = document.querySelector(".search-results-card-container");
const pageOverlay = document.querySelector("#page-overlay");

const searchHeader = document.querySelector("#search-results-header");
const searchKeyword = document.querySelector("#search-keyword");

const errorMessage =
  "This is a rather exotic ingredient you are trying to cook with.";

function fetchResults(urlLink) {
  return new Promise(function (resolve, reject) {
    fetch(urlLink, {
      method: "GET",
    })
      .then(function (response) {
        if (!response.ok) {
          reject(new Error(response.status));
        } else {
          return response.json();
        }
      })
      .then(function (goodResult) {
        if (!goodResult.error) {
          resolve(goodResult);
        } else {
          reject(goodResult);
        }
      })
      .catch(function (error) {
        reject(error);
      });
  });
}

function displayErrorMessage(selectedDiv) {
  clearDiv(selectedDiv);
  selectedDiv.textContent = `${errorMessage}`;
  selectedDiv.classList.add("error");
}

function clearDiv(selectedDiv) {
  if (selectedDiv.hasChildNodes()) {
    while (selectedDiv.firstElementChild) {
      selectedDiv.removeChild(selectedDiv.firstChild);
    }
    selectedDiv.textContent = "";
    selectedDiv.classList.remove("error");
  } else {
    selectedDiv.textContent = "";
    selectedDiv.classList.remove("error");
  }
}

function getSearchResult(urlLink, searchTerm) {
  let newUrl;
  if (searchTerm) {
    newUrl = `${urlLink}${searchTerm}`;
  } else {
    throw new Error("No search term provided.");
  }
  return fetchResults(newUrl)
    .then(function (result) {
      // console.log(result);
      return result;
    })
    .catch(function (error) {
      // console.log(error);
      return error;
    });
}

function showOverlay() {
  pageOverlay.style.visibility = "visible";
  pageOverlay.style.zIndex = 999;
  document.body.classList.add("overlay-active");
}

function hideOverlay() {
  pageOverlay.style.visibility = "hidden";
  pageOverlay.style.zIndex = -1;
  document.body.classList.remove("overlay-active");
}

function createChildElement(parentElement, elementType, classNames = []) {
  const childElement = parentElement.appendChild(
    document.createElement(elementType)
  );

  if (classNames.length > 0) {
    childElement.classList.add(...classNames);
  }
  return childElement;
}

function recipeDetailsPopover(
  thisTitle,
  theseInstructions,
  theseIngredients,
  thisTagList,
  thisGeography,
  thisCategory,
  thisYoutubeLink
) {
  showOverlay();
  const popoverContent = createChildElement(pageOverlay, "div", ["pop-over"]);
  popoverContent.style.visibility = "visible";
  popoverContent.style.zIndex = 1000;

  const popoverHeader = createChildElement(popoverContent, "div", [
    "popover-header",
  ]);
  const closeButton = createChildElement(popoverHeader, "button", [
    "fa-solid",
    "fa-xmark",
    "close-button",
  ]);

  function closeThisDiv() {
    closeButton.parentNode.parentNode.remove();
    hideOverlay();
  }
  closeButton.addEventListener("click", closeThisDiv);

  const popoverTitle = createChildElement(popoverContent, "div", [
    "popover-title",
  ]);
  popoverTitle.textContent = thisTitle;

  const mealDetails = createChildElement(popoverContent, "div", [
    "meal-details",
  ]);
  mealDetails.textContent = thisCategory;

  const geographyIcon = createChildElement(mealDetails, "i", [
    "fa-solid",
    "fa-globe",
  ]);
  const geograpyText = createChildElement(mealDetails, "div", []);
  geograpyText.textContent = thisGeography;

  const tagsSection = createChildElement(popoverContent, "ul", ["tags"]);

  if (thisTagList) {
    for (i = 0; i < thisTagList.length; i++) {
      let tag = tagsSection.appendChild(document.createElement("li"));
      tag.classList.add("tag");
      tag.textContent = `${thisTagList[i]}`;
    }
  }

  const popoverGrid = createChildElement(popoverContent, "div", [
    "popover-grid",
  ]);

  const instructions = createChildElement(popoverGrid, "div", ["instructions"]);
  instructions.textContent = "Instructions:";

  const instructionsContent = createChildElement(instructions, "div", [
    "instructions-content",
  ]);
  instructionsContent.textContent = theseInstructions;

  const ingredientSection = createChildElement(popoverGrid, "div", [
    "ingredients",
  ]);
  ingredientSection.textContent = `Ingredients:`;

  const ingredientListSection = createChildElement(
    ingredientSection,
    "div",
    []
  );
  const ingredientList = createChildElement(ingredientListSection, "ul", [
    "ingredients-list",
  ]);

  for (i = 0; i < theseIngredients.length; i++) {
    let newIngredient = ingredientList.appendChild(
      document.createElement("li")
    );
    newIngredient.textContent = `${theseIngredients[i].name} - ${theseIngredients[i].measure}`;
  }

  const youtubeIframe = createChildElement(popoverContent, "iframe", [
    "youtube-iframe",
  ]);
  youtubeIframe.src = thisYoutubeLink;
}

function recipeDetails(recipeUrl, recipeId) {
  if (!recipeId) {
    console.error("No ID provided.");
    return;
  }
  getSearchResult(recipeUrl, recipeId).then(function (details) {
    const mealName = details.meals[0].strMeal;
    const geography = details.meals[0].strArea;
    const category = details.meals[0].strCategory;
    const mealPicture = details.meals[0].strMealThumb;
    const instructions = details.meals[0].strInstructions;
    const watchYoutube = details.meals[0].strYoutube;
    const videoId = watchYoutube.split("v=")[1];
    const youtubeLink = `${youtubeEmbed}${videoId}`;
    const ingredients = [];
    for (let i = 1; i <= 20; i++) {
      const ingredientName = details.meals[0][`strIngredient${i}`];
      const ingredientMeasure = details.meals[0][`strMeasure${i}`];

      if (ingredientName && ingredientMeasure) {
        ingredients.push({
          name: ingredientName,
          measure: ingredientMeasure.trim(),
        });
      }
    }
    const tags = details.meals[0].strTags;
    let tagsList = tags;
    if (tags) {
      tagsList = tags.split(",");
    }

    let popover = recipeDetailsPopover(
      mealName,
      instructions,
      ingredients,
      tagsList,
      geography,
      category,
      youtubeLink
    );
  });
}

function mealCard(mealName, mealPicture, mealId, spaceToDisplay) {
  //create the card
  const newMealCard = createChildElement(spaceToDisplay, "div", ["meal-card"]);

  //add picture
  const mealCardPicture = createChildElement(newMealCard, "img", [
    "meal-card-picture",
  ]);
  mealCardPicture.src = mealPicture;

  //create div to hold name and button
  const mealCardFooter = createChildElement(newMealCard, "div", [
    "meal-card-footer",
  ]);

  const mealTitle = createChildElement(mealCardFooter, "div", [
    "meal-card-name",
  ]);
  mealTitle.textContent = mealName;

  const detailsButton = createChildElement(mealCardFooter, "button", [
    "get-recipe-button",
  ]);
  detailsButton.id = `card_${mealId}`;
  detailsButton.textContent = "Get Recipe";
  const thisDetailsButton = document.getElementById(`${detailsButton.id}`);
  function showPopover() {
    recipeDetails(recipeUrl, mealId);
  }
  thisDetailsButton.addEventListener("click", showPopover);
}

function printSearchResults(urlLink, searchTerm, spaceToDisplay) {
  clearDiv(spaceToDisplay);

  if (!searchTerm) {
    console.error("No keyword provided");
    displayErrorMessage(spaceToDisplay);
    searchHeader.style.visibility = "hidden";
    return;
  }
  searchHeader.style.visibility = "visible";
  searchKeyword.textContent = `${searchTerm}`;
  getSearchResult(urlLink, searchTerm)
    .then(function (result) {
      const meal = result.meals;
      if (meal) {
        for (let i = 0; i < meal.length; i++) {
          const thisMealName = meal[i].strMeal;
          const thisMealPicture = meal[i].strMealThumb;
          const thisMealId = meal[i].idMeal;
          mealCard(thisMealName, thisMealPicture, thisMealId, spaceToDisplay);
        }
      } else {
        throw new Error("No results for such term.");
      }
    })
    .catch(function (error) {
      console.error(error);
      displayErrorMessage(spaceToDisplay);
    });
}

function findRecipe() {
  printSearchResults(theMealFilterUrl, inputKeyword.value, cardsContainer);
}

searchRecipeButton.addEventListener("click", findRecipe);

inputKeyword.addEventListener("keypress", function (e) {
  if (e.key === "Enter") {
    printSearchResults(theMealFilterUrl, inputKeyword.value, cardsContainer);
  }
});

function refreshPage() {
  location.reload(true);
}
