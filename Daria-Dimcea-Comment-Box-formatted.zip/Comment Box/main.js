const reviewSection = document.querySelector("#review-section");
const genericComment = document.querySelector("#generic-comment");
const userName = document.querySelector("#username");
const userEmail = document.querySelector("#user-email");
const reviewText = document.querySelector("#review-text");
const reviewForm = document.querySelector("#review-form");

const commentSection = document.querySelector(".add-comment-section");
const addCommentButton = document.querySelector(".add-comment-button");

const newCommentText = document.querySelector("#new-comment");
const publishCommentButton = document.querySelector("#publish-comment-button");

const avatarList = [
  "./Avatars/avatar01.svg",
  "./Avatars/avatar02.svg",
  "./Avatars/avatar03.svg",
  "./Avatars/avatar04.svg",
  "./Avatars/avatar05.svg",
  "./Avatars/avatar06.svg",
  "./Avatars/avatar07.svg",
  "./Avatars/avatar08.svg",
  "./Avatars/avatar09.svg",
  "./Avatars/avatar10.svg",
  "./Avatars/avatar11.svg",
  "./Avatars/avatar12.svg",
  "./Avatars/avatar13.svg",
  "./Avatars/avatar14.svg",
  "./Avatars/avatar15.svg",
];

let commentList = [];

//add new comment section
function addComment() {
  commentSection.style.display = "flex";
}
addCommentButton.addEventListener("click", addComment);

//publish new comment
function publishComment() {
  if (newCommentText.value) {
    let prevId = -1;
    for (let i = 0; i < commentList.length; i++) {
      prevId = Math.max(prevId, `${commentList[i].commentId}`);
    }
    let newId = prevId + 1;
    let newComment = {
      commentId: newId,
      commentEmail: "username@email.com",
      commentUserName: "username",
      commentText: newCommentText.value,
    };
    commentList.push(newComment);
    reviewForm.reset();
  }
}

function clearChildren(selectedDiv) {
  if (selectedDiv.hasChildNodes()) {
    while (selectedDiv.firstElementChild) {
      selectedDiv.removeChild(selectedDiv.firstChild);
    }
  }
}
function removeComment() {
  console.log(this.getAttribute("comment-id"));
  let indexValue = commentList.findIndex(
    (item) => item.commentId == this.getAttribute("comment-id")
  );
  console.log(indexValue);
  commentList.splice(indexValue, 1);
  displayComment();
}

function displayComment() {
  clearChildren(reviewSection);

  commentList.forEach((comment) => {
    const { commentId, commentUserName, commentEmail, commentText } = comment;
    const avatar = avatarList[Math.floor(Math.random() * avatarList.length)];

    const newComment = createCommentElement(
      commentId,
      avatar,
      commentUserName,
      commentEmail,
      commentText
    );
    reviewSection.appendChild(newComment);
  });

  commentSection.style.display = "none";
}

function createCommentElement(
  commentId,
  avatar,
  userName,
  userEmail,
  commentText
) {
  const newComment = document.createElement("div");
  newComment.classList.add("generic-comment");

  const newHeader = createHeaderElement(commentId, avatar, userName, userEmail);
  newComment.appendChild(newHeader);

  const newCommentInput = document.createElement("div");
  newCommentInput.classList.add("review-content");
  newCommentInput.textContent = commentText;
  newComment.appendChild(newCommentInput);

  return newComment;
}

function createHeaderElement(commentId, avatar, userName, userEmail) {
  const newHeader = document.createElement("div");
  newHeader.classList.add("review-header");

  const newUserDetails = document.createElement("div");
  newUserDetails.classList.add("user-details");

  const newUserLogo = document.createElement("img");
  newUserLogo.classList.add("user-logo");
  newUserLogo.src = avatar;

  const newContactInfo = document.createElement("div");
  newContactInfo.classList.add("contact-info");

  const newUserName = createDivElement("user-name", userName);
  const newUserEmail = createDivElement("user-email", userEmail);

  newContactInfo.appendChild(newUserName);
  newContactInfo.appendChild(newUserEmail);

  newUserDetails.appendChild(newUserLogo);
  newUserDetails.appendChild(newContactInfo);

  const newDeleteButton = createDeleteButton(commentId);
  newHeader.appendChild(newUserDetails);
  newHeader.appendChild(newDeleteButton);

  return newHeader;
}

function createDivElement(className, textContent) {
  const div = document.createElement("div");
  div.classList.add(className);
  div.textContent = textContent;
  return div;
}

function createDeleteButton(commentId) {
  const newDeleteButton = document.createElement("input");
  newDeleteButton.classList.add("delete-comment", "fa-solid", "fa-xmark");
  newDeleteButton.setAttribute("comment-id", commentId);
  newDeleteButton.type = "button";
  newDeleteButton.value = "\uf00d";
  newDeleteButton.addEventListener("click", removeComment);

  return newDeleteButton;
}

function clearChildren(element) {
  while (element.firstChild) {
    element.removeChild(element.firstChild);
  }
}

publishCommentButton.addEventListener("click", () => {
  publishComment();
  displayComment();
});
