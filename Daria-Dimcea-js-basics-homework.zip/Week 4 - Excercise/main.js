//exercise 1 - concatenate two strings
const frontEnd = ["HTML", "CSS", "JS", "React", "Redux"];
const backEnd = ["Node", "Express", "MongoDB"];

const fullStack = frontEnd.concat(backEnd);

console.log(fullStack);

//excerise 2 - add, remove, edit values in an array

const shoppingCart = ["Milk", "Coffee", "Tea", "Honey"];
const myAlergies = ["Polen", "Honey"];

if (shoppingCart[0] !== "Meat") {
  shoppingCart.splice(0, 0, "Meat");
}

if (shoppingCart[length.shoppingCart] !== "Sugar") {
  shoppingCart.push("Sugar");
}

if (myAlergies.includes("Honey") && shoppingCart.includes("Honey")) {
  const alergicToHoney = (element) => element == "Honey";
  const indexHoney = shoppingCart.findIndex(alergicToHoney);
  shoppingCart.splice(indexHoney, 1);
}

if (shoppingCart.includes("Tea")) {
  const findTea = (element) => element == "Tea";
  const indexTea = shoppingCart.findIndex(findTea);
  shoppingCart.splice(indexTea, 1, "Green Tea");
}

console.log(shoppingCart);

//excercise 3 - check if season is Autumn, Winter, Spring, or Summer

let yearMonth = [
  {
    season: "Autumn",
    value: "September",
  },
  {
    season: "Autumn",
    value: "October",
  },
  {
    season: "Autumn",
    value: "November",
  },
  {
    season: "Winter",
    value: "December",
  },
  {
    season: "Winter",
    value: "January",
  },
  {
    season: "Winter",
    value: "February",
  },
  {
    season: "Spring",
    value: "March",
  },
  {
    season: "Spring",
    value: "April",
  },
  {
    season: "Spring",
    value: "May",
  },
  {
    season: "Summer",
    value: "June",
  },
  {
    season: "Summer",
    value: "July",
  },
  {
    season: "Summer",
    value: "August",
  },
];

const month = "October";

let monthOfYear = yearMonth.find((monthOfYear) => monthOfYear.value == month);
if (monthOfYear == undefined) {
  console.log("There is no such month on planet Earth");
} else {
  console.log(monthOfYear.season);
}

//exercise 4 - maximum number of pages that can be printed

let inkLevels = {
  cyan: 23,
  magenta: 0,
  yellow: 20,
};

pagesPrintable = Math.min(inkLevels.cyan, inkLevels.magenta, inkLevels.yellow);

if (pagesPrintable == 0) {
  console.log("No pages can be printed.");
} else {
  console.log(pagesPrintable);
}
