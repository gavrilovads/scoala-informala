// Function to handle button click event
function handleClick() {
  // Change the URL without reloading the page
  history.pushState({}, "", "new-page");

  // Update content
  const updatedSection = document.querySelector("#new-content");
  const newContent = document.createElement("div");

  newContent.innerHTML = `
        <p>This content is dynamically loaded without page reload.</p>
    `;
  //Each click on the button add a new line
  updatedSection.appendChild(newContent);
}

document
  .getElementById("changeContentBtn")
  .addEventListener("click", handleClick);
