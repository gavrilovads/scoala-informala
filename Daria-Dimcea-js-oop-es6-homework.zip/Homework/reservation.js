export default class Reservation {
  constructor(name, date, time, guestCount) {
    this.name = name;
    this.date = date;
    this.time = time;
    this.guestCount = guestCount;
  }
}
