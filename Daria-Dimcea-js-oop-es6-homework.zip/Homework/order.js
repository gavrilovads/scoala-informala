export default class Order {
  constructor(tableNumber, items) {
    this.tableNumber = tableNumber;
    this.items = items && Array.isArray(items) ? items : [];
    this.totalPrice = 0;

    if (items && Array.isArray(items)) {
      this.calculateTotalPrice();
    }
  }
  calculateTotalPrice() {
    this.totalPrice = 0;
    this.items.forEach((item) => {
      this.totalPrice += item.price || 0;
    });
    return this.totalPrice;
  }
}
