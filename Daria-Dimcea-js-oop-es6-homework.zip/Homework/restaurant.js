import MenuItem from "./menuItem.js";
import Reservation from "./reservation.js";

export default class Restaurant {
  constructor(name, capacity, reservations = [], menu = [], orders = []) {
    this.name = name;
    this.capacity = capacity;
    this.reservations = reservations;
    this.menu = menu;
    this.orders = orders;
  }
  addReservation(newReservation) {
    if (!(newReservation instanceof Reservation)) {
      console.error("This is not a valid new reservation.");
      return;
    }
    this.reservations.push(newReservation);
  }

  removeReservation(reservationName) {
    const reservationIndex = this.reservations.findIndex(
      (reservation) => reservation.name === reservationName
    );
    if (reservationIndex !== -1) {
      this.reservations.splice(reservationIndex, 1);
      console.log(`Reservation for '${reservationName}' removed successfully.`);
    } else {
      console.log(`Reservation for '${reservationName}' not found.`);
    }
  }
  checkAvailability() {
    return this.capacity - this.getGuestCount();
  }
  listReservations() {
    return this.reservations.map((reservation) => reservation.name);
  }
  isReservationAvailable(reservationName) {
    return this.reservations.some(
      (reservation) => reservation.name === reservationName
    );
  }
  isFullyBooked() {
    return this.checkAvailability() <= 0;
  }
  getGuestCount() {
    return this.reservations.reduce(
      (total, reservation) => total + reservation.guestCount,
      0
    );
  }
  sortReservationsAlphabetically() {
    return this.reservations.map((reservation) => reservation.name).sort();
  }
  addOrder(order) {
    this.orders.push(order);
  }
  removeOrder(tableNumber) {
    const orderIndex = this.orders.findIndex(
      (orderIndex) => order.tableNumber === tableNumber
    );
    if (orderIndex !== -1) {
      this.orders.splice(orderIndex, 1);
      console.log(
        `Order for the table number ${tableNumber} was successfully removed.`
      );
    } else {
      console.log(
        `There doesn't seem to be an order for table number ${tableNumber}.`
      );
    }
  }
  listOrders() {
    return this.orders;
  }
  getTotalRevenue() {
    return this.orders.reduce((total, order) => total + order.totalPrice, 0);
  }
  addMenuItem(item) {
    if (typeof item !== "object" || !(item instanceof MenuItem)) {
      console.error(`This is not a valid menu item`);
      return;
    }
    const existingItemIndex = this.menu.findIndex(
      (menuItem) => menuItem.name === item.name
    );

    if (existingItemIndex !== -1) {
      console.log(`Menu item '${item.name}' already exists.`);
      return;
    }
    this.menu.push(item);
  }

  removeMenuItem(itemName) {
    const itemIndex = this.menu.findIndex(
      (menuItem) => menuItem.name === itemName
    );
    if (itemIndex !== -1) {
      this.menu.splice(itemIndex, 1);
      console.log(`${itemName} was removed form the Menu.`);
    } else {
      console.log(`There is no such item on the Menu.`);
    }
  }
  listMenuItems() {
    return this.menu;
  }
}
