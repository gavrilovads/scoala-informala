import Restaurant from "./restaurant.js";
import Reservation from "./reservation.js";
import MenuItem from "./menuItem.js";
import Order from "./order.js";
import OnlineOrder from "./onlineOrder.js";
import Guest from "./guest.js";

const shengYang = new Restaurant("Sheng Yang", 20);
console.log(shengYang);

const espresso = new MenuItem("Espresso", 10);
const capuccino = new MenuItem("Cappuccino", 20);
const soup = new MenuItem("Soup", 20);
const steak = new MenuItem("Steak", 35);
const ragu = new MenuItem("Ragu", 25);
const carbonara = new MenuItem("Carbonara", 20);

shengYang.addMenuItem(espresso);
shengYang.addMenuItem(capuccino);
shengYang.addMenuItem(soup);
shengYang.addMenuItem(steak);
shengYang.addMenuItem(ragu);
shengYang.addMenuItem(carbonara);

const jane = new Reservation("Jane", "Sept 10th", "5pm", 4);
console.log(jane);

const john = new Reservation("John", "Sept 7th", "3pm", 2);
console.log(john);

shengYang.addReservation(jane);
shengYang.addReservation(john);

const johanna = new Guest(
  "Johanna",
  "Sept 7th",
  "4pm",
  3,
  "Lactose intolerant."
);
console.log(johanna);
const janesOrder = new Order(100, [ragu, carbonara]);
console.log(janesOrder);

const johnsOrder = new OnlineOrder(101, [capuccino, steak]);
johnsOrder.deliveryAddress = "Somewhere over the rainbow.";
console.log(johnsOrder);

console.log(shengYang.listMenuItems());

console.log(shengYang.getGuestCount());
console.log(shengYang.isFullyBooked());
