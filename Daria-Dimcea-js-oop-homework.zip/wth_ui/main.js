// get element references
const displayBorrowedBooksModal = document.getElementById(
  "displayBorrowedBooksModal"
);
const displayBorrowedBooksButton = document.getElementById(
  "displayBorrowedBooksButton"
);
const displayMemberDropdown = document.getElementById("displayMemberDropdown");
const displayBorrowedBooksContainer = document.getElementById(
  "displayBorrowedBooksContainer"
);
const closeModal = document.querySelector("#close-modal");

// book constructor function
function Book(title, author, ISBN) {
  this.title = title;
  this.author = author;
  this.ISBN = ISBN;
  this.borrowed = false; // default to not borrowed
}

// display book information method
Book.prototype.displayInfo = function () {
  console.log(
    `title: ${this.title}, author: ${this.author}, ISBN: ${
      this.ISBN
    }, borrowed: ${this.borrowed ? "Yes" : "No"}`
  );
};

// create an instance of Book
const tooGood = new Book(
  "You're too good to feel this bad",
  "Nate Dallas",
  "0578643427"
);

// fiction book constructor inheriting from Book
function FictionBook(title, author, ISBN, genre) {
  Book.call(this, title, author, ISBN);
  this.genre = genre;
}

// set up prototype chain for FictionBook
FictionBook.prototype = Object.create(Book.prototype);
FictionBook.prototype.constructor = FictionBook;

// overwrite displayInfo method for FictionBook
FictionBook.prototype.displayInfo = function () {
  console.log(
    `title: ${this.title}, author: ${this.author}, ISBN: ${this.ISBN}, genre: ${this.genre}`
  );
};

// create instances of FictionBook
const hpss = new FictionBook(
  "Harry Potter and the Sorcerer's stone",
  "J.K. Rowling",
  "9780439362139",
  "Sci-Fi"
);
const dune = new FictionBook(
  "Dune",
  "Frank Herbert",
  "0441172719",
  "Science Fiction"
);

// library constructor
function Library() {
  this.books = [];
  this.members = [];
}

// method to add a book to the library
Library.prototype.addBook = function (book) {
  this.books.push(book);
  console.log(`${book.title} was added to the library.`);
};

// create a library instance
const library = new Library();
library.addBook(hpss);
library.addBook(dune);

// method to add a member to the library
Library.prototype.addMember = function (member) {
  this.members.push(member);
  console.log(`${member.name} is now a member of the library.`);
};

// method to get borrowed books for a member
Library.prototype.getBorrowedBooks = function (memberName) {
  const member = this.members.find((member) => member.name === memberName);
  return member ? member.borrowedBooks : [];
};

// library member constructor
function LibraryMember(name) {
  this.name = name;
  this.borrowedBooks = [];
}

// method to borrow a book
Library.prototype.borrowBook = function (memberName, bookTitle) {
  const member = this.members.find((member) => member.name === memberName);
  const book = this.books.find((book) => book.title === bookTitle);

  if (member && book) {
    if (!book.borrowed) {
      member.borrowBook(book);
      console.log(`${memberName} borrowed ${bookTitle}.`);
    } else {
      console.log(`${bookTitle} is already borrowed by another member.`);
    }
  } else {
    console.log(`Member or book not found.`);
  }
};

// method to borrow a book for a member
LibraryMember.prototype.borrowBook = function (book) {
  if (!book.borrowed) {
    this.borrowedBooks.push(book);
    book.borrowed = true;
  } else {
    console.log(`Sorry, ${book.title} is already borrowed by another member.`);
  }
};

// method to return a book for a member
LibraryMember.prototype.returnBook = function (book) {
  const index = this.borrowedBooks.indexOf(book);
  if (index !== -1) {
    this.borrowedBooks.splice(index, 1);
    book.borrowed = false;
    console.log(`${this.name} returned ${book.title}.`);
  } else {
    console.log(
      `${this.name} does not have ${book.title} in their borrowed books.`
    );
  }
};

// create library member instances
const daria = new LibraryMember("Daria");
library.addMember(daria);

// get element references for add book functionality
const addBookButtton = document.querySelector("#addBookButton");
const addBookPopover = document.querySelector("#addBookPopover");
const addBookSubmitBtn = document.getElementById("addBookSubmit");

// show add book popover on button click
addBookButtton.addEventListener("click", function () {
  addBookPopover.style.display = "block";
});

addBookSubmitBtn.addEventListener("click", function (event) {
  event.preventDefault(); // Prevent the default form submission behavior

  const title = document.getElementById("title").value;
  const author = document.getElementById("author").value;
  const ISBN = document.getElementById("ISBN").value;
  const genre = document.getElementById("genre").value;

  // Check if all required fields are provided
  if (title && author && ISBN) {
    // Check if the genre is Fantasy or Sci-Fi
    const newBook =
      genre === "Fantasy" || genre === "Sci-Fi"
        ? new FictionBook(title, author, ISBN, genre)
        : new Book(title, author, ISBN);

    // Add the book to the library
    library.addBook(newBook);

    // Create a new div for the success message
    const successMessageDiv = document.createElement("div");
    successMessageDiv.classList.add("success");
    successMessageDiv.textContent = `${newBook.title} was successfully added to the library.`;

    // Append the success message div as a child of addBookPopover
    addBookPopover.appendChild(successMessageDiv);

    // Clear the success message div after 3 seconds
    setTimeout(() => {
      successMessageDiv.textContent = "";
    }, 3000);
  } else {
    // Display an error message for missing inputs
    const errorMessageDiv = document.createElement("div");
    errorMessageDiv.textContent =
      "Please provide values for all required fields (Title, Author, ISBN).";
    errorMessageDiv.classList.add("error");
    addBookPopover.appendChild(errorMessageDiv);

    // Clear the error message div after 3 seconds
    setTimeout(() => {
      errorMessageDiv.textContent = "";
    }, 3000);
  }

  // Reset input fields
  document.getElementById("title").value = "";
  document.getElementById("author").value = "";
  document.getElementById("ISBN").value = "";
  document.getElementById("genre").value = "Fantasy";
});

// Function to populate a dropdown with options
function populateDropdown(dropdown, options) {
  // Clear existing options
  dropdown.innerHTML = "";

  // Create and append new options
  options.forEach((option) => {
    const optionElement = document.createElement("option");
    optionElement.value = option;
    optionElement.textContent = option;
    dropdown.appendChild(optionElement);
  });
}

// Get element references for borrowing books functionality
const borrowBooksBtn = document.getElementById("borrowBooksButton");
const borrowBooksPopover = document.getElementById("borrowBooksPopover");
const borrowBooksSubmitBtn = document.getElementById("borrowBooksSubmit");
const borrowMemberDropdown = document.getElementById("borrowMember");
const borrowBookDropdown = document.getElementById("borrowBook");

borrowBooksBtn.addEventListener("click", function () {
  // Populate the member dropdown
  populateDropdown(
    borrowMemberDropdown,
    library.members.map((member) => member.name)
  );
  populateDropdown(
    borrowBookDropdown,
    library.books.map((book) => book.title)
  );

  borrowBooksPopover.style.display = "block";
});

let statusUpdate = document.createElement("div");
statusUpdate.id = "statusUpdate"; // Set an ID for styling or reference
const closeButton = borrowBooksPopover.querySelector(".closeButton");

// Event listener for the close button
closeButton.addEventListener("click", function () {
  statusUpdate.textContent = ""; // Clear the status message
  statusUpdate.classList.remove("success", "warning", "error"); // Remove all classes
  borrowBooksPopover.style.display = "none"; // Hide the popover
});

// Append the statusUpdate div to borrowBooksPopover
borrowBooksPopover.appendChild(statusUpdate);

borrowBooksSubmitBtn.addEventListener("click", function () {
  const memberName = borrowMemberDropdown.value;
  const bookTitle = borrowBookDropdown.value;
  const member = library.members.find((member) => member.name === memberName);
  const book = library.books.find((book) => book.title === bookTitle);

  // Clear previous error or success message
  statusUpdate.textContent = "";
  statusUpdate.classList.remove("success", "warning", "error");

  if (member && book) {
    if (!book.borrowed) {
      member.borrowBook(book);
      console.log(`${memberName} borrowed ${bookTitle}.`);

      // Display success message
      statusUpdate.textContent = `${bookTitle} was successfully borrowed by ${memberName}.`;
      statusUpdate.classList.add("success");
      // Set a timeout to clear the success message after 3 seconds
      setTimeout(() => {
        statusUpdate.textContent = "";
      }, 3000);
    } else {
      // Display error message
      statusUpdate.textContent = `${bookTitle} is already borrowed by another member.`;
      statusUpdate.classList.add("warning");
    }
  } else {
    // Display error message
    statusUpdate.textContent = "Member or book not found.";
    console.log(`Member or book not found.`);
    statusUpdate.classList.add("error");
  }
});

function clearDiv(container) {
  while (container.firstChild) {
    container.removeChild(container.firstChild);
  }
}

// get element references for displaying borrowed books functionality
const seeBorrowedBooksButton = document.getElementById("seeBorrowedBooks");
seeBorrowedBooksButton.addEventListener("click", function () {
  // Populate the member dropdown in the modal
  populateDropdown(
    displayMemberDropdown,
    library.members.map((member) => member.name)
  );

  // Display the modal
  displayBorrowedBooksModal.style.display = "block";
});

displayBorrowedBooksButton.addEventListener("click", function () {
  // Get the selected member from the dropdown
  const selectedMember = displayMemberDropdown.value;

  clearDiv(displayBorrowedBooksContainer);

  // Find the member in the library
  const member = library.members.find(
    (member) => member.name === selectedMember
  );

  // Display borrowed books for the selected member
  if (member) {
    if (member.borrowedBooks.length > 0) {
      member.borrowedBooks.forEach((book) => {
        // Create a div element for each book and display its information
        const bookCard = document.createElement("div");
        bookCard.classList.add("book-card");

        // Create divs for title, author, ISBN, and genre
        const titleDiv = document.createElement("div");
        titleDiv.textContent = `Title: ${book.title}`;
        bookCard.appendChild(titleDiv);

        const authorDiv = document.createElement("div");
        authorDiv.textContent = `Author: ${book.author}`;
        bookCard.appendChild(authorDiv);

        const isbnDiv = document.createElement("div");
        isbnDiv.textContent = `ISBN: ${book.ISBN}`;
        bookCard.appendChild(isbnDiv);

        if (book.genre) {
          const genreDiv = document.createElement("div");
          genreDiv.textContent = `Genre: ${book.genre}`;
          bookCard.appendChild(genreDiv);
        }

        displayBorrowedBooksContainer.appendChild(bookCard);
      });
    } else {
      const displayBorrowedBooksContainerError = document.createElement("div");
      displayBorrowedBooksContainerError.textContent = `No books borrowed by ${selectedMember}.`;
      displayBorrowedBooksContainer.appendChild(
        displayBorrowedBooksContainerError
      );
    }
  } else {
    const displayBorrowedBooksContainerError = document.createElement("div");
    displayBorrowedBooksContainerError.textContent = "Member not found.";
    console.log(`Member not found.`);
    displayBorrowedBooksContainer.appendChild(
      displayBorrowedBooksContainerError
    );
  }
});

// close modal on close button click
closeModal.addEventListener("click", function () {
  // Clear the container with results
  displayBorrowedBooksContainer.innerHTML = "";

  // Hide the modal
  displayBorrowedBooksModal.style.display = "none";
});

let closeBookModal = document.querySelector("#close-book-modal");
closeBookModal.addEventListener("click", function () {
  addBookPopover.style.display = "none";
});

// initialize 5 library members
const samWinchester = new LibraryMember("Sam Winchester");
const deanWinchester = new LibraryMember("Dean Winchester");
const castiel = new LibraryMember("Castiel");
const rowenaMacLeod = new LibraryMember("Rowena MacLeod");
const crowley = new LibraryMember("Crowley");

// add members to the library
library.addMember(samWinchester);
library.addMember(deanWinchester);
library.addMember(castiel);
library.addMember(rowenaMacLeod);
library.addMember(crowley);

// create fantasy books
const lotrBook1 = new FictionBook(
  "The Fellowship of the Ring",
  "J.R.R. Tolkien",
  "9780544003415",
  "Fantasy"
);
const lotrBook2 = new FictionBook(
  "The Two Towers",
  "J.R.R. Tolkien",
  "9780544003330",
  "Fantasy"
);
const lotrBook3 = new FictionBook(
  "The Return of the King",
  "J.R.R. Tolkien",
  "9780544338012",
  "Fantasy"
);
const lotrBook4 = new FictionBook(
  "The Hobbit",
  "J.R.R. Tolkien",
  "9780547928227",
  "Fantasy"
);
const lotrBook5 = new FictionBook(
  "The Silmarillion",
  "J.R.R. Tolkien",
  "9780544273442",
  "Fantasy"
);

// create sci-fi books
const sciFiBook1 = new FictionBook(
  "The War of the Worlds",
  "H.G. Wells",
  "9780141439976",
  "Sci-Fi"
);
const sciFiBook2 = new FictionBook(
  "The Time Machine",
  "H.G. Wells",
  "9780451531571",
  "Sci-Fi"
);
const sciFiBook3 = new FictionBook(
  "The Invisible Man",
  "H.G. Wells",
  "9781503262114",
  "Sci-Fi"
);

// create simple books
const nonSciFiFantasyBook1 = new Book(
  "To Kill a Mockingbird",
  "Harper Lee",
  "0061120081"
);
const nonSciFiFantasyBook2 = new Book("1984", "George Orwell", "0451524934");
const nonSciFiFantasyBook3 = new Book(
  "Pride and Prejudice",
  "Jane Austen",
  "9780141439518"
);
const nonSciFiFantasyBook4 = new Book(
  "The Great Gatsby",
  "F. Scott Fitzgerald",
  "9780743273565"
);
const nonSciFiFantasyBook5 = new Book(
  "The Catcher in the Rye",
  "J.D. Salinger",
  "9780316769480"
);

// add all books to the library
library.addBook(lotrBook1);
library.addBook(lotrBook2);
library.addBook(lotrBook3);
library.addBook(lotrBook4);
library.addBook(lotrBook5);
library.addBook(sciFiBook1);
library.addBook(sciFiBook2);
library.addBook(sciFiBook3);
library.addBook(nonSciFiFantasyBook1);
library.addBook(nonSciFiFantasyBook2);
library.addBook(nonSciFiFantasyBook3);
library.addBook(nonSciFiFantasyBook4);
library.addBook(nonSciFiFantasyBook5);
